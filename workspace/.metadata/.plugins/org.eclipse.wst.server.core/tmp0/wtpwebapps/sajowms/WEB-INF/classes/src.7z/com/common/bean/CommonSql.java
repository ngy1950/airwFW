package com.common.bean;

public class CommonSql {
	private String sqlkey;
	private String sqltyp;
	private String dbmsty;
	private String sqlsta;
	private String sqldsc;
}
