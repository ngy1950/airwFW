package com.common.controller;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.common.bean.CommonConfig;
import com.common.bean.CommonLabel;
import com.common.bean.CommonSearch;
import com.common.bean.CommonUser;
import com.common.bean.DataMap;
import com.common.bean.FileRepository;
import com.common.bean.SystemConfig;
import com.common.bean.TableColumn;
import com.common.bean.User;
import com.common.service.CommonService;
import com.common.util.PostRequest;
import com.common.util.SqlUtil;
import com.common.util.Util;

@Controller
public class LoginController extends BaseController {
	
	private static Logger log = Logger.getLogger(LoginController.class);
	
	@Autowired
	private CommonService commonService;
	
	@Autowired
	private CommonLabel commonLabel;
	
	@Autowired
	private CommonSearch commonSearch;
	
	@Autowired
	private FileRepository respository;
	
	@Autowired
	private SystemConfig systemConfig;
	
	@Autowired
	private CommonUser commonUser;
	
	@RequestMapping("/common/json/glogin.*")
	public String login(HttpSession session, HttpServletRequest request, Map model) throws SQLException{
		DataMap map = (DataMap)request.getAttribute(CommonConfig.PARAM_ATT_KEY);
		
		String serverip = getIp(request); //접속 ip
		String useros = getOS(request); //접속 os
		String browser = getBrower(request); //접속 브라우저
		
		map.setModuleCommand("Common", "LOGIN");
		
		User user = (User)commonService.getObj(map);

		
		if(user != null){
			commonService.update(map);
			
			//로그인 이력 저장
			map.setModuleCommand("Common", "LOGHIS");
			map.put("USERID", user.getUserid()); //아이디 
			map.put("SERVERIP", serverip ); //IP
			map.put("USEROS", useros); // OS
			map.put("BROWSER", browser); // 브라우저
			map.put("STATUS", "S"); // 상태
			map.put("DESC01", "성공"); // 상태명
			commonService.insert(map);
			
			//계정잠금 확인
			if("V".equals(user.getDelmak())){
				model.put("data", "F");
				return JSON_VIEW;
			}
			
			map.setModuleCommand("Common", "USRLO");
			map.put(CommonConfig.SES_USER_ID_KEY, user.getUserid());
			List<DataMap> list = commonService.getList(map);
			DataMap usrlo = new DataMap();
			DataMap row;
			List data;
			String progid;
			for(int i=0;i<list.size();i++){
				row = list.get(i);
				progid = row.getString("PROGID");
				if(usrlo.containsKey(progid)){
					data = usrlo.getList(progid);
					data.add(row);
				}else{
					List newData = new ArrayList();
					newData.add(row);
					usrlo.put(progid, newData);
				}
			}
			
			user.setUsrlo(usrlo);
			
			map.setModuleCommand("Common", "USRPH");
			list = commonService.getList(map);
			DataMap usrph = new DataMap();
			DataMap usrphc = new DataMap();
			DataMap usrpi = new DataMap();
			String defchk;
			for(int i=0;i<list.size();i++){
				row = list.get(i);
				progid = row.getString("PROGID");
				if(usrph.containsKey(progid)){
					data = usrph.getList(progid);
					data.add(row);
				}else{
					List newData = new ArrayList();
					newData.add(row);
					usrph.put(progid, newData);
				}
				defchk =  row.getString("DEFCHK");
				if(defchk.equals("V") && !usrphc.containsKey(progid)){
					usrphc.put(progid, row.getString("PARMKY"));
					row.setModuleCommand("Common", "USRPI");
					List itemList = commonService.getList(row);
					usrpi.put(progid, itemList);
				}		
			}
			
			user.setUsrph(usrph);
			user.setUsrpi(usrpi);
			
			map.setModuleCommand("Common", "MACGL");
			map.put("ACGRID", user.getUserg1());
			list = commonService.getList(map);
			
			DataMap usrac = new DataMap();
			for(int i=0;i<list.size();i++){
				row = list.get(i);
				progid = row.getString("PROGID");
				if(usrac.containsKey(progid)){
					data = usrac.getList(progid);
					data.add(row);
				}else{
					List newData = new ArrayList();
					newData.add(row);
					usrac.put(progid, newData);
				}
			}
			
			user.setUsrac(usrac);
			
			map.setModuleCommand("Wms", "USERINFO");
			
			DataMap userInfo = (DataMap)commonService.getMap(map);
			request.getSession().setAttribute(CommonConfig.SES_USER_INFO_KEY, userInfo);
			
			user.addUserData("userIndo", userInfo);
			
			if(!commonUser.addUserIdMap(session, map.getString("USERID"), map.getString(CommonConfig.SES_USER_TYPE_KEY))){
				commonUser.killSession(map.getString("USERID"), "");
				commonUser.addUserIdMap(session, map.getString("USERID"), map.getString(CommonConfig.SES_USER_TYPE_KEY));
			}
			
			commonUser.addSessionMap(session.getId(), user);
			
			request.getSession().setAttribute(CommonConfig.SES_USER_OBJECT_KEY, user);
			request.getSession().setAttribute(CommonConfig.SES_USER_ID_KEY, user.getUserid());
			request.getSession().setAttribute(CommonConfig.SES_USER_NAME_KEY, user.getNmlast());
			request.getSession().setAttribute(CommonConfig.SES_USER_WHAREHOUSE_KEY, map.getString("WAREKY"));
			request.getSession().setAttribute(CommonConfig.SES_USER_OWNER_KEY, user.getOwner());
			request.getSession().setAttribute(CommonConfig.SES_USER_COMPANY_KEY, user.getCompky());
			request.getSession().setAttribute(CommonConfig.SES_USER_LANGUAGE_KEY, map.getString("LANGKY"));
			request.getSession().setAttribute(CommonConfig.SES_USER_EMPL_ID_KEY, user.getEmplid());
			request.getSession().setAttribute(CommonConfig.SES_USER_THEME_KEY, CommonConfig.SYSTEM_THEME_PATH);
						
			model.put("data", "S");
			
			map.setModuleCommand("Common", "ROLCT");
			
			List<DataMap> rolctList = commonService.getList(map);
			if(rolctList.size() < 1){
				model.put("data", "R");
			}
			
			log.debug(user);
		}else{

			//로그인 이력 저장
			map.put("USERID", map.get("USERID")); //아이디 
			map.put("SERVERIP", serverip ); //IP
			map.put("USEROS", useros); // OS
			map.put("BROWSER", browser); // 브라우저
			map.put("STATUS", "E"); // 상태
			map.put("DESC01", "ID , PASSWORD 입력 오류"); // 상태명
			map.setModuleCommand("Common", "LOGHIS");
			commonService.insert(map);
			
			//로그인 실패 횟수 저장
			map.setModuleCommand("Common", "LOGINERR");
			commonService.update(map);
			
			model.put("data", "F");
		}	
		
		return JSON_VIEW;
	}	
	
	 private String getIp(HttpServletRequest request) {
		 
	        String ip = request.getHeader("X-Forwarded-For");
	 
	        if (ip == null) {
	            ip = request.getHeader("Proxy-Client-IP");
	        }
	        if (ip == null) {
	            ip = request.getHeader("WL-Proxy-Client-IP"); // 웹로직
	        }
	        if (ip == null) {
	            ip = request.getHeader("HTTP_CLIENT_IP");
	        }
	        if (ip == null) {
	            ip = request.getHeader("HTTP_X_FORWARDED_FOR");
	        }
	        if (ip == null) {
	            ip = request.getRemoteAddr();
	        }
	        return ip;
	 }
	 
	 private String getBrower(HttpServletRequest request){
		 String brower = null;
		 String agent = request.getHeader("User-Agent");
		 
		 if (agent != null) {
		    if (agent.indexOf("Trident") > -1) {
		       brower = "MSIE";
		    } else if (agent.indexOf("Chrome") > -1) {
		       brower = "Chrome";
		    } else if (agent.indexOf("Opera") > -1) {
		       brower = "Opera";
		    } else if (agent.indexOf("iPhone") > -1 && agent.indexOf("Mobile") > -1) {
		       brower = "iPhone";
		    } else if (agent.indexOf("Android") > -1 && agent.indexOf("Mobile") > -1) {
		       brower = "Android";
		    }
		 }
		 return brower;
	 }
	 
	 private String getOS(HttpServletRequest request){
		 String os = null;
		 String agent = request.getHeader("User-Agent");

		 if(agent.indexOf("NT 6.0") != -1) os = "Windows Vista/Server 2008";
		 else if(agent.indexOf("NT 5.2") != -1) os = "Windows Server 2003";
		 else if(agent.indexOf("NT 5.1") != -1) os = "Windows XP";
		 else if(agent.indexOf("NT 5.0") != -1) os = "Windows 2000";
		 else if(agent.indexOf("NT") != -1) os = "Windows NT";
		 else if(agent.indexOf("9x 4.90") != -1) os = "Windows Me";
		 else if(agent.indexOf("98") != -1) os = "Windows 98";
		 else if(agent.indexOf("95") != -1) os = "Windows 95";
		 else if(agent.indexOf("Win16") != -1) os = "Windows 3.x";
		 else if(agent.indexOf("Windows") != -1) os = "Windows";
		 else if(agent.indexOf("Linux") != -1) os = "Linux";
		 else if(agent.indexOf("Macintosh") != -1) os = "Macintosh";
		 else os = ""; 
		 
		 return os;
	 }
}