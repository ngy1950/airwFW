package com.common.dao;

import org.apache.log4j.Logger;

public class BaseDAO {
	private static Logger log = Logger.getLogger(BaseDAO.class);
}