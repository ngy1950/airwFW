package com.common.exception;

public class SessionEmptyException extends Exception {

	private static final long serialVersionUID = -3267282275312661737L;
}
