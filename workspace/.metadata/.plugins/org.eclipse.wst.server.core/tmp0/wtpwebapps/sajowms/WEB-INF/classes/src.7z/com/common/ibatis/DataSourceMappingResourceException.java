package com.common.ibatis;

public class DataSourceMappingResourceException extends RuntimeException {

	private static final long serialVersionUID = 2752548466107517765L;

	public DataSourceMappingResourceException(String message, Throwable cause) {
		super(message, cause);
	}
}
