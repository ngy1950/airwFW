package com.common.service;

public class BaseService {

}
