package com.common.service;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;

import com.common.bean.CommonConfig;
import com.common.bean.DataMap;
import com.common.dao.CommonDAO;
import com.common.bean.DataMap;
import com.wms.service.OutboundService;

@Service
public class SystemService extends BaseService {
	private static Logger log = Logger.getLogger(SystemService.class);
	
	@Autowired
	public CommonDAO commonDao;
	
	@Transactional
	public int saveUi01(DataMap map) throws SQLException {
		int count = 0;
		DataMap row;  
		
		List<DataMap> list = map.getList("list");
		
		for(int i = 0 ; i < list.size() ; i ++){
			row = list.get(i).getMap("map");
			
			if(" ".equals(row.getString("UROLKY"))){
				System.out.println(">>>>>>>>>>");
				row.setModuleCommand("System", "USSRA1");
				count += commonDao.delete(row);
			}
			else{
			row.setModuleCommand("System", "USSRA1");
			count += commonDao.delete(row);
			
			row.setModuleCommand("System", "USSRA1");
			count += commonDao.update(row);
			}
		}
	
		return count;
	}

	@Transactional
	public int saveYhu01(DataMap map) throws SQLException {
		int count = 0;
		
		DataMap list = map.getMap("list").getMap("map");
		
		if(map.get("flag").equals("U")){
			list.setModuleCommand("System", "SHLPHU");
		}else{
			list.setModuleCommand("System", "SHLPHI");
		}
		count += commonDao.update(list);

		return count;
	}
	
/*	@Transactional
	public int saveYhi01(DataMap map) throws SQLException {
		int count = 0;
		
		DataMap list = map.getMap("list").getMap("map");
	
		
		count += commonDao.update(list);
		
		return count;
	}*/

	@Transactional
	public int saveUr01(DataMap map) throws SQLException {
		int count = 0;
		DataMap row;
		DataMap list = map.getMap("list").getMap("map");
		
		//List<DataMap> list = map.getList("list");
		//row = list.get(0).getMap("map");
			
		list.setModuleCommand("System", "UR01TOP");
		count += commonDao.update(list);
		
		return count;
	}

	@Transactional
	public int saveYs01(DataMap map) throws SQLException {
		int count = 0;
		if(map.get("flag").equals("U")){
			map.setModuleCommand("System", "JQMAPU");			
		}else{
			map.setModuleCommand("System", "SQLKEYCnt");
			DataMap cntMap = commonDao.getMap(map);
			if(cntMap != null){
				if(  cntMap.getInt("CNT") >0){
					return 0;
				}
			}
			map.setModuleCommand("System", "JQMAPI");	
		}
			
		count += commonDao.update(map);
		
		return count;
	}
	
	@Transactional
	public int delYs01(DataMap map) throws SQLException {
		int count=0;
		map.setModuleCommand("System", "JQMAP");
		count += commonDao.delete(map);
		return count;
	}
	
	@Transactional
	public int delYH01(DataMap map) throws SQLException {
		int count=0;
		map.setModuleCommand("System", "SHLPHAD");
		count += commonDao.delete(map);
		map.setModuleCommand("System", "SHLPIAD");
		count += commonDao.delete(map);
		return count;
	}

	
}