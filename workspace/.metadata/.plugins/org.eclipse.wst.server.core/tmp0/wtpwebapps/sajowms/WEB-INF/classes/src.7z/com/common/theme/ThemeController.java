package com.common.theme;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.common.bean.CommonConfig;
import com.common.bean.DataMap;
import com.common.controller.BaseController;
import com.common.service.CommonService;

@Controller
public class ThemeController extends BaseController {
	
	private static Logger log = Logger.getLogger(ThemeController.class);
	
	@Autowired
	private CommonService commonService;
	
	@RequestMapping("/theme/siwms/{page}.*")
	public String siwmspage(@PathVariable String page){
		return "/siwms/"+page;
	}
	
	@RequestMapping("/theme/siwms/{module}/{page}.*")
	public String siwmsmpage(@PathVariable String module, @PathVariable String page){
		
		return "/siwms/"+module+"/"+page;
	}
	
	@RequestMapping("/gsfresh/index.*")
	public String index(HttpServletRequest request, Map model) throws SQLException{
		DataMap map = (DataMap)request.getAttribute(CommonConfig.PARAM_ATT_KEY);
		map.setModuleCommand("Wms", "WAHMACOMBO");
		
		List list = commonService.getList(map);
		
		model.put("WAHMACOMBO", list);
		
		map.setModuleCommand("Common", "COMCOMBO");
		map.put("CODE", "LANGKY");
		
		List list1 = commonService.getList(map);
		
		model.put("LANGKY", list1);
		
		map.setModuleCommand("Common", "LOGINMSG");
		List list2 = commonService.getList(map);
		
		model.put("MSG", list2);
		
		return "/gsfresh/index";
	}
	
	@RequestMapping("/gsfresh/left.*")
	public String leftMenu(HttpSession session, HttpServletRequest request, Map model) throws SQLException{
		String langky = session.getAttribute(CommonConfig.SES_USER_LANGUAGE_KEY).toString();
		String userid = session.getAttribute(CommonConfig.SES_USER_ID_KEY).toString();
		
		DataMap map = new DataMap("Common", "MENUTREE");
		map.put("LANGKY", langky);
		map.put("USERID", userid);
		
		List<DataMap> list = commonService.getList(map);
		
		session.setAttribute(CommonConfig.SES_USER_MENU_KEY, list);
		
		DataMap urlMap = new DataMap();
		DataMap row;
		String tmpUrl;
		for(int i=0;i<list.size();i++){
			row = list.get(i);
			tmpUrl = row.getString("PGPATH");
			if(tmpUrl.trim().length() != 0){
				if(tmpUrl.substring(0, 2).equals("./")){
					tmpUrl = tmpUrl.substring(1);
				}
				if(tmpUrl.substring(tmpUrl.length()-3).equals("jsp")){
					tmpUrl = tmpUrl.substring(0,tmpUrl.length()-3)+"page";
				}
				urlMap.put(tmpUrl, true);
			}			
		}
		urlMap.put("/common/main.page", true);
		urlMap.put("/common/left.page", true);
		urlMap.put("/common/top.page", true);
		urlMap.put("/common/wintab.page", true);
		urlMap.put("/common/info.page", true);
		session.setAttribute(CommonConfig.SES_USER_URL_KEY, urlMap);
		
		model.put("list", list);
		
		return "/gsfresh/left";
	}
	
	@RequestMapping("/gsfresh/{page}.*")
	public String gsfreshspage(@PathVariable String page){
		return "/gsfresh/"+page;
	}
	
	@RequestMapping("/gsfresh/{module}/{page}.*")
	public String gsfreshmpage(@PathVariable String module, @PathVariable String page){
		
		return "/gsfresh/"+module+"/"+page;
	}
	
	@RequestMapping("/joongwon/index.*")
	public String joongwonindex(HttpServletRequest request, Map model) throws SQLException{
		DataMap map = (DataMap)request.getAttribute(CommonConfig.PARAM_ATT_KEY);
		map.setModuleCommand("Wms", "WAHMACOMBO");
		
		List list = commonService.getList(map);
		
		model.put("WAHMACOMBO", list);
		
		map.setModuleCommand("Common", "COMCOMBO");
		map.put("CODE", "LANGKY");
		
		List list1 = commonService.getList(map);
		
		model.put("LANGKY", list1);
		
		map.setModuleCommand("Common", "LOGINMSG");
		List list2 = commonService.getList(map);
		
		model.put("MSG", list2);
		
		return "/joongwon/index";
	}
	
	@RequestMapping("/joongwon/left.*")
	public String joongwonleftMenu(HttpSession session, HttpServletRequest request, Map model) throws SQLException{
		String langky = session.getAttribute(CommonConfig.SES_USER_LANGUAGE_KEY).toString();
		String userid = session.getAttribute(CommonConfig.SES_USER_ID_KEY).toString();
		
		DataMap map = new DataMap("Common", "MENUTREE");
		map.put("LANGKY", langky);
		map.put("USERID", userid);
		
		List<DataMap> list = commonService.getList(map);
		
		session.setAttribute(CommonConfig.SES_USER_MENU_KEY, list);
		
		DataMap urlMap = new DataMap();
		DataMap row;
		String tmpUrl;
		for(int i=0;i<list.size();i++){
			row = list.get(i);
			tmpUrl = row.getString("PGPATH");
			if(tmpUrl.trim().length() != 0){
				if(tmpUrl.substring(0, 2).equals("./")){
					tmpUrl = tmpUrl.substring(1);
				}
				if(tmpUrl.substring(tmpUrl.length()-3).equals("jsp")){
					tmpUrl = tmpUrl.substring(0,tmpUrl.length()-3)+"page";
				}
				urlMap.put(tmpUrl, true);
			}			
		}
		urlMap.put("/common/main.page", true);
		urlMap.put("/common/left.page", true);
		urlMap.put("/common/top.page", true);
		urlMap.put("/common/wintab.page", true);
		urlMap.put("/common/info.page", true);
		session.setAttribute(CommonConfig.SES_USER_URL_KEY, urlMap);
		
		model.put("list", list);
		
		return "/joongwon/left";
	}
	
	@RequestMapping("/joongwon/{page}.*")
	public String joongwonspage(@PathVariable String page){
		return "/joongwon/"+page;
	}
	
	@RequestMapping("/joongwon/{module}/{page}.*")
	public String joongwonmpage(@PathVariable String module, @PathVariable String page){
		
		return "/joongwon/"+module+"/"+page;
	}
}