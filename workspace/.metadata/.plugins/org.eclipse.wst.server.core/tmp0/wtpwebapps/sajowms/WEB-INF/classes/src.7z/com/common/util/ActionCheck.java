package com.common.util;

import org.springframework.stereotype.Repository;

@Repository
public class ActionCheck {

}