package com.common.util;

import java.io.File;
import java.io.FileOutputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.CountDownLatch;

import com.common.bean.DataMap;
import com.sap.conn.jco.AbapException;
import com.sap.conn.jco.JCoContext;
import com.sap.conn.jco.JCoDestination;
import com.sap.conn.jco.JCoDestinationManager;
import com.sap.conn.jco.JCoException;
import com.sap.conn.jco.JCoField;
import com.sap.conn.jco.JCoFieldIterator;
import com.sap.conn.jco.JCoFunction;
import com.sap.conn.jco.JCoFunctionTemplate;
import com.sap.conn.jco.JCoParameterList;
import com.sap.conn.jco.JCoStructure;
import com.sap.conn.jco.JCoTable;
import com.sap.conn.jco.ext.DestinationDataProvider;

/**
 * basic examples for Java to ABAP communication  
 */
public class RfcCallClient
{
 
	static String ABAP_AS = "ABAP_AS_WITHOUT_POOL";
    static String ABAP_AS_POOLED = "ABAP_AS_WITH_POOL";
    
    private void main(DataMap baseMap)
    {
        Properties connectProperties = new Properties();
        connectProperties.setProperty(DestinationDataProvider.JCO_ASHOST, baseMap.getString("ASHOST"));
        connectProperties.setProperty(DestinationDataProvider.JCO_SYSNR,  baseMap.getString("SYSNUM"));
        connectProperties.setProperty(DestinationDataProvider.JCO_CLIENT, baseMap.getString("CLIENT"));
        connectProperties.setProperty(DestinationDataProvider.JCO_USER,   baseMap.getString("USERID"));
        connectProperties.setProperty(DestinationDataProvider.JCO_PASSWD, baseMap.getString("PASSWD"));
        connectProperties.setProperty(DestinationDataProvider.JCO_LANG,   baseMap.getString("LANGKY"));
        connectProperties.setProperty(DestinationDataProvider.JCO_R3NAME, baseMap.getString("R3NAME"));
        connectProperties.setProperty(DestinationDataProvider.JCO_GROUP,  baseMap.getString("SGROUP"));
        //createDestinationDataFile(ABAP_AS, connectProperties);
        connectProperties.setProperty(DestinationDataProvider.JCO_POOL_CAPACITY, baseMap.getString("CAPACT"));
        connectProperties.setProperty(DestinationDataProvider.JCO_PEAK_LIMIT,    baseMap.getString("SLIMIT"));
        createDestinationDataFile(ABAP_AS_POOLED, connectProperties);        
    }
    
    private void createDestinationDataFile(String destinationName, Properties connectProperties)
    {
        File destCfg = new File(destinationName+".jcoDestination");
        try
        {
            FileOutputStream fos = new FileOutputStream(destCfg, false);
            connectProperties.store(fos, "for tests only !");
            fos.close();
        }
        catch (Exception e)
        {
            throw new RuntimeException("Unable to create the destination files", e);
        }
    }
    
    /**
     * map 형태로 넘어온 데이터를 처리한다.
     * @param map
     * @return
     * @throws JCoException
     */
    public List<DataMap> mapExecute(DataMap basemap, DataMap map) throws JCoException
    {
    	main(basemap);
    	
    	List<DataMap> returnList = new ArrayList();
    	
    	JCoDestination destination = JCoDestinationManager.getDestination(ABAP_AS_POOLED);
    	
        // ... it always has a reference to a metadata repository
        JCoFunction function = destination.getRepository().getFunction(basemap.getString("IF_NAME"));
    
        if(function == null)
            throw new RuntimeException("FUNCTION not found in SAP.");
       // List<HashMap> list = new ArrayList();
	   // HashMap paramMap = new HashMap();
	    
        try
        {
	    	JCoParameterList paramlist = function.getImportParameterList();
        	Iterator keys = map.keySet().iterator();
	    	String key = "";
	    	while(keys.hasNext()){
				key = (String) keys.next();
				paramlist.setValue(key, map.get(key));
			}
	    
            //execute, i.e. send the function to the ABAP system addressed 
            //by the specified destination, which then returns the function result.
            //All necessary conversions between Java and ABAP data types
            //are done automatically.
            function.execute(destination);
        }
        catch(AbapException e)
        {
        	return returnList;
        }
        
        JCoTable returnTable = function.getTableParameterList().getTable(basemap.getString("IF_RETBL"));
        
        int rfcRowNum = returnTable.getNumRows();
		for(int j = 0; j < rfcRowNum; j++){
			DataMap returnMap = new DataMap();
			returnTable.firstRow();
			JCoFieldIterator jrfit = returnTable.getFieldIterator();
			JCoField jField = null;
			while(jrfit.hasNextField()){
				jField = jrfit.nextField();
				if(jField.getName().equals("CODE") && jField.getValue().equals("")){
					returnMap.put(jField.getName(), function.getExportParameterList().getValue("E_SUBRC"));
				}else if(jField.getName().equals("MESSAGE") && jField.getValue().equals("")){
					returnMap.put(jField.getName(), function.getExportParameterList().getValue("E_MESSAGE"));
				}else{
					returnMap.put(jField.getName(), jField.getValue());
				}
			}

			returnList.add(j, returnMap);
			returnTable.deleteRow(0);
		}
		
        return returnList;
    }
    
    /**
     * list 로 넘어온 데이터를 테이블에 담아 처리한다.
     * @param list
     * @param map
     * @return
     * @throws JCoException
     */
    public List<DataMap> tableExecute(ArrayList<DataMap> list, DataMap map) throws JCoException
    {
    	main(map);
    	
    	List<DataMap> returnList = new ArrayList();
    	
    	JCoDestination destination = JCoDestinationManager.getDestination(ABAP_AS_POOLED);
    	
    	// ... it always has a reference to a metadata repository
        JCoFunction function = destination.getRepository().getFunction(map.getString("IF_NAME"));
    
        if(function == null)
            throw new RuntimeException("FUNCTION not found in SAP.");
       // List<HashMap> list = new ArrayList();
	   // HashMap paramMap = new HashMap();
	    
        try
        {
	    	JCoTable table = function.getTableParameterList().getTable(map.getString("IF_RETBL"));
	    	
	    	DataMap reqMap = new DataMap();
	    	for(int i = 0; i < list.size(); i++){
		        table.appendRow();
	        	//JCoParameterList paramlist = function.getImportParameterList();
		        reqMap = list.get(i);
		        
		        Iterator keys = reqMap.keySet().iterator();
		    	String key = "";
		    	while(keys.hasNext()){
					key = (String) keys.next();
					table.setValue(key, reqMap.get(key));
				}
	    	}
	    	
	    	//execute, i.e. send the function to the ABAP system addressed 
            //by the specified destination, which then returns the function result.
            //All necessary conversions between Java and ABAP data types
            //are done automatically.
            function.execute(destination);
        }
        catch(AbapException e)
        {
        	return returnList;
        }
        
        JCoTable returnTable = function.getTableParameterList().getTable(map.getString("IF_RETBL"));
        
		int rfcRowNum = returnTable.getNumRows();
		for(int j = 0; j < rfcRowNum; j++){
			DataMap returnMap = new DataMap();
			returnTable.firstRow();
			JCoFieldIterator jrfit = returnTable.getFieldIterator();
			JCoField jField = null;
			while(jrfit.hasNextField()){
				jField = jrfit.nextField();
				if(jField.getName().equals("CODE") && jField.getValue().equals("")){
					returnMap.put(jField.getName(), function.getExportParameterList().getValue("E_SUBRC"));
				}else if(jField.getName().equals("MESSAGE") && jField.getValue().equals("")){
					returnMap.put(jField.getName(), function.getExportParameterList().getValue("E_MESSAGE"));
				}else{
					returnMap.put(jField.getName(), jField.getValue());
				}
			}

			returnList.add(j, returnMap);
			returnTable.deleteRow(0);
		}
        
        return returnList;
    }
    
    /**
     * table / map 사용
     * @param baseMap
     * @param paramMap
     * @param paramList2
     * @return
     * @throws JCoException
     */
    public List<DataMap> dualListExecute(DataMap baseMap, DataMap paramMap, List<DataMap> paramList) throws JCoException
    {
    	main(baseMap);
    	
    	List<DataMap> returnList = new ArrayList();
    	JCoDestination destination = JCoDestinationManager.getDestination(ABAP_AS_POOLED);
    	
        // ... it always has a reference to a metadata repository
        JCoFunction function = destination.getRepository().getFunction(baseMap.getString("IF_NAME"));
    
        if(function == null)
            throw new RuntimeException("FUNCTION not found in SAP.");
       // List<HashMap> list = new ArrayList();
	   // HashMap paramMap = new HashMap();
	    
        try
        {
        	JCoParameterList param = function.getImportParameterList();
        	Iterator keys = paramMap.keySet().iterator();
	    	String key = "";
	    	while(keys.hasNext()){
				key = (String) keys.next();
				param.setValue(key, paramMap.get(key));
			}
	    	
	    	JCoTable table = function.getTableParameterList().getTable(baseMap.getString("IF_FRTBL"));
	    	DataMap reqMap = new DataMap();
			for(int i = 0; i < paramList.size(); i++){
				table.appendRow();
				reqMap = paramList.get(i);
		        
		        Iterator listkeys = reqMap.keySet().iterator();
		    	String listkey = "";
		    	while(listkeys.hasNext()){
		    		listkey = (String) listkeys.next();
		    		table.setValue(listkey, reqMap.get(listkey));
				}
			}
		
            //execute, i.e. send the function to the ABAP system addressed 
            //by the specified destination, which then returns the function result.
            //All necessary conversions between Java and ABAP data types
            //are done automatically.
            function.execute(destination);
        }
        catch(AbapException e)
        {
        	return returnList;
        }
       
        JCoTable returnTable = function.getTableParameterList().getTable(baseMap.getString("IF_RETBL"));
        
        int rfcRowNum = returnTable.getNumRows();
		for(int j = 0; j < rfcRowNum; j++){
			DataMap returnMap = new DataMap();
			returnTable.firstRow();
			JCoFieldIterator jrfit = returnTable.getFieldIterator();
			JCoField jField = null;
			while(jrfit.hasNextField()){
				jField = jrfit.nextField();
				if(jField.getName().equals("CODE") && jField.getValue().equals("")){
					returnMap.put(jField.getName(), function.getExportParameterList().getValue("E_SUBRC"));
				}else if(jField.getName().equals("MESSAGE") && jField.getValue().equals("")){
					returnMap.put(jField.getName(), function.getExportParameterList().getValue("E_MESSAGE"));
				}else{
					returnMap.put(jField.getName(), jField.getValue());
				}
			}

			returnList.add(j, returnMap);
			returnTable.deleteRow(0);
		}
		
        return returnList;
    }
    
    public List<DataMap> dummyMapExecute(DataMap map)
    {
    	List<DataMap> returnList = new ArrayList();
    	
		Iterator keys = map.keySet().iterator();
    	String key = "";
    	DataMap returnMap = new DataMap();
    	while(keys.hasNext()){
			key = (String) keys.next();
			returnMap.put(key, map.get(key));
			returnMap.put("CODE", "00");
			returnMap.put("MESSAGE", "Not Connected SAP");
			returnMap.put("MTSNR", "999999999X");
		}
    	returnList.add(0, returnMap);
    	
        return returnList;
    }
    
	public List<DataMap> dummayTableExecute(ArrayList<DataMap> list, DataMap map)
    {
    	List<DataMap> returnList = new ArrayList();
    	
    	DataMap rsMap = new DataMap();
    	for(int i = 0; i < list.size(); i++){
    		rsMap = list.get(i);
    		Iterator keys = rsMap.keySet().iterator();
        	String key = "";
        	DataMap returnMap = new DataMap();
	    	while(keys.hasNext()){
				key = (String) keys.next();
				returnMap.put(key, rsMap.get(key));
				returnMap.put("CODE", "00");
				returnMap.put("MESSAGE", "Not Connected SAP");
				returnMap.put("MTSNR", "999999999X");
			}
	    	returnList.add(i, returnMap);
    	}
    	
        return returnList;
    }
	
	public List<DataMap> dummyDualListExecute(DataMap baseMap, DataMap paramMap, List<DataMap> list)
    {
		List<DataMap> returnList = new ArrayList();
    	
    	DataMap rsMap = new DataMap();
    	for(int i = 0; i < list.size(); i++){
    		rsMap = list.get(i);
    		Iterator keys = rsMap.keySet().iterator();
        	String key = "";
        	DataMap returnMap = new DataMap();
	    	while(keys.hasNext()){
				key = (String) keys.next();
				returnMap.put(key, rsMap.get(key));
				returnMap.put("CODE", "00");
				returnMap.put("MESSAGE", "Not Connected SAP");
				returnMap.put("MTSNR", "999999999X");
			}
	    	returnList.add(i, returnMap);
    	}
    	return returnList;
    }
}
