package com.wms.controller;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.common.bean.CommonConfig;
import com.common.controller.BaseController;
import com.common.service.CommonService;
import com.common.bean.DataMap;
import com.wms.service.OutboundService;

@Controller
public class OutboundController extends BaseController {
	
	private static Logger log = Logger.getLogger(OutboundController.class);
	
	@Autowired
	private OutboundService outboundService;	
	
	@Autowired
	private CommonService commonService;
	
	@RequestMapping("/wms/outbound/json/DL01Validation.*")
	public String DL01Validation(HttpServletRequest request, Map model) throws SQLException{				
		DataMap map = (DataMap)request.getAttribute(CommonConfig.PARAM_ATT_KEY);
		try{
			String result = outboundService.saveDL01ValueCheck(map);
			
			model.put("data", result);
		}catch(Exception e){
			model.put("data", "error");
			log.debug("Controller Error = "+e);
		}
		return JSON_VIEW;
	}
	
	/**
	 * 고객오더/창간 오더 정보 저장
	 * @param request
	 * @param model
	 * @return
	 * @throws SQLException
	 */
	@RequestMapping("/wms/outbound/json/DL01Save.*")
	public String DL01Save(HttpServletRequest request, Map model) throws SQLException{				
		DataMap map = (DataMap)request.getAttribute(CommonConfig.PARAM_ATT_KEY);
		
		Object data = outboundService.saveDl01(map);
		
		model.put("data", data);
		
		return JSON_VIEW;
	}
	
	/**
	 * 체크된 헤더 정보 일괄 저장
	 * @param request
	 * @param model
	 * @return
	 * @throws SQLException
	 */
	@RequestMapping("/wms/outbound/json/DL01AllChkeckSave.*")
	public String DL01AllChkeckSave(HttpServletRequest request, Map model) throws SQLException{				
		DataMap map = (DataMap)request.getAttribute(CommonConfig.PARAM_ATT_KEY);
		
		Object data;
		try {
			data = outboundService.saveDL01AllChkeck(map);
		} catch (Exception e) {
			data = 0;
		}
		
		model.put("data", data);
		
		return JSON_VIEW;
	}
	
	@RequestMapping("/wms/outbound/json/DL01IndexSelectCheckSave.*")
	public String DL01IndexSelectCheckSave(HttpServletRequest request, Map model) throws SQLException{				
		DataMap map = (DataMap)request.getAttribute(CommonConfig.PARAM_ATT_KEY);
		
		Object data;
		try {
			data = outboundService.DL01IndexSelectCheckSave(map);
		} catch (Exception e) {
			data = 0;
		}
		
		model.put("data", data);
		
		return JSON_VIEW;
	}
	
	/**
	 * 고객오더/창간오더 정보 할당처리
	 * @param request
	 * @param model
	 * @return
	 * @throws SQLException
	 */
	@RequestMapping("/wms/outbound/json/DL01Assignment.*")
	public String DL01Assignment(HttpServletRequest request, Map model) throws SQLException{				
		DataMap map = (DataMap)request.getAttribute(CommonConfig.PARAM_ATT_KEY);
		
		Object data = outboundService.assignmentDl01(map);
		
		model.put("data", data);
		
		return JSON_VIEW;
	}
	
	@RequestMapping("/wms/outbound/json/DL01AllCheckAssignment.*")
	public String DL01AllCheckAssignment(HttpServletRequest request, Map model) throws SQLException{				
		DataMap map = (DataMap)request.getAttribute(CommonConfig.PARAM_ATT_KEY);
		
		Object data;
		try {
			data = outboundService.assignmentAllDl01(map);
		} catch (Exception e) {
			data = 0;
		}
		
		model.put("data", data);
		
		return JSON_VIEW;
	}
	
	@RequestMapping("/wms/outbound/json/DL01IndexSelectCheckAssignment.*")
	public String DL01IndexSelectCheckAssignment(HttpServletRequest request, Map model) throws SQLException{				
		DataMap map = (DataMap)request.getAttribute(CommonConfig.PARAM_ATT_KEY);
		
		Object data;
		try {
			data = outboundService.DL01IndexSelectCheckAssignment(map);
		} catch (Exception e) {
			data = 0;
		}
		
		model.put("data", data);
		
		return JSON_VIEW;
	}
	
	@RequestMapping("/wms/outbound/json/DL01Barcode.*")
	public String DL01Barcode(HttpServletRequest request, Map model) throws SQLException{				
		DataMap map = (DataMap)request.getAttribute(CommonConfig.PARAM_ATT_KEY);
		
		List list = outboundService.DL01Barcode(map);
		
		model.put("data", list);
		
		return JSON_VIEW;
	}
	
	@RequestMapping("/wms/outbound/DL04pop.*")
	public String DL04pop(HttpServletRequest request, Map model) throws SQLException{				
		DataMap map = (DataMap)request.getAttribute(CommonConfig.PARAM_ATT_KEY);
		
		model.put("param", map);

		return "/wms/outbound/DL04POP";
	}
	
	@RequestMapping("/wms/outbound/json/DL04POPSave.*")
	public String DL04POPSave(HttpServletRequest request, Map model) throws SQLException{				
		DataMap map = (DataMap)request.getAttribute(CommonConfig.PARAM_ATT_KEY);
		
		Object data;
		try {
			data = outboundService.DL04POPSave(map);
		} catch (Exception e) {
			data = 0;
		}
		
		model.put("data", data);

		return JSON_VIEW;
	}
	
	@RequestMapping("/wms/outbound/DL04PopSearch.*")
	public String DL04PopSearch(HttpServletRequest request, Map model) throws SQLException{				
		DataMap map = (DataMap)request.getAttribute(CommonConfig.PARAM_ATT_KEY);
		
		model.put("param", map);
		
		map.setModuleCommand("WmsOutbound", "SEARCHITEM");
		
		List itemList = commonService.getList(map);
		
		model.put("itemList", itemList);
		
		return "/wms/outbound/DL04POP";
	}
	
	@RequestMapping("/wms/outbound/json/DL04Assignment.*")
	public String DL04Assignment(HttpServletRequest request, Map model) throws SQLException{				
		DataMap map = (DataMap)request.getAttribute(CommonConfig.PARAM_ATT_KEY);
		
		Object data = outboundService.DL04Assignment(map);
		
		model.put("data", data);
		
		return JSON_VIEW;
	}
	
	/**
	 * 오더 정보 삭제
	 * @param request
	 * @param model
	 * @return
	 * @throws SQLException
	 */
	@RequestMapping("/wms/outbound/json/DL01OrderDelete.*")
	public String DL01OrderDelete(HttpServletRequest request, Map model) throws SQLException{				
		DataMap map = (DataMap)request.getAttribute(CommonConfig.PARAM_ATT_KEY);
		
		Object data = outboundService.DL01OrderDelete(map);
		
		model.put("data", data);
		
		return JSON_VIEW;
	}
	
	@RequestMapping("/wms/outbound/json/DL04Delete.*")
	public String DL04Delete(HttpServletRequest request, Map model) throws SQLException{				
		DataMap map = (DataMap)request.getAttribute(CommonConfig.PARAM_ATT_KEY);
		
		Object data = outboundService.DL04Delete(map);
		
		model.put("data", data);
		
		return JSON_VIEW;
	}
	
	@RequestMapping("/wms/outbound/json/DL04orderDelete.*")
	public String DL04AllDelete(HttpServletRequest request, Map model) throws SQLException{				
		DataMap map = (DataMap)request.getAttribute(CommonConfig.PARAM_ATT_KEY);
		
		Object data = outboundService.DL04orderDelete(map);
		
		model.put("data", data);
		
		return JSON_VIEW;
	}

	
	@RequestMapping("/wms/outbound/json/validatePikingSave.*")
	public String validatePikingSave(HttpServletRequest request, Map model) throws SQLException{				
		DataMap map = (DataMap)request.getAttribute(CommonConfig.PARAM_ATT_KEY);
		
		String result = outboundService.validatePikingSave(map);
		
		model.put("data", result);
		
		return JSON_VIEW;
	}
	
	@RequestMapping("/wms/outbound/json/DL06PikingSave.*")
	public String DL06PikingSave(HttpServletRequest request, Map model) throws SQLException{				
		DataMap map = (DataMap)request.getAttribute(CommonConfig.PARAM_ATT_KEY);
		
		Object data = outboundService.DL06PikingSave(map);
		
		model.put("data", data);
		
		return JSON_VIEW;
	}
	
	/**
	 * 오더 조회 삭제
	 * @param request
	 * @param model
	 * @return
	 * @throws SQLException
	 */
	@RequestMapping("/wms/outbound/json/TM04Delete.*")
	public String TM04Delete(HttpServletRequest request, Map model) throws SQLException{				
		DataMap map = (DataMap)request.getAttribute(CommonConfig.PARAM_ATT_KEY);
		
		Object data = outboundService.TM04Delete(map);
		
		model.put("data", data);
		
		return JSON_VIEW;
	}
	@RequestMapping("/wms/outbound/json/SaveTM05.*")
	public String saveTM05(HttpServletRequest request, Map model) throws SQLException{				
		DataMap map = (DataMap)request.getAttribute(CommonConfig.PARAM_ATT_KEY);
		Object data = outboundService.SaveTM05(map);
		model.put("data", data);
		return JSON_VIEW;
	}
	@RequestMapping("/wms/outbound/json/SaveTM03.*")
	public String saveTM03(HttpServletRequest request, Map model) throws SQLException{				
		DataMap map = (DataMap)request.getAttribute(CommonConfig.PARAM_ATT_KEY);
		Object data = outboundService.SaveTM03(map);
		model.put("data", data);
		return JSON_VIEW;
	}
	
	@RequestMapping("/wms/outbound/json/TM07_Delete.*")
	public String DeleteTM07(HttpServletRequest request, Map model) throws SQLException{				
		DataMap map = (DataMap)request.getAttribute(CommonConfig.PARAM_ATT_KEY);
		
		Object data = outboundService.DeleteTM07(map);
		
		model.put("data", data);
		
		return JSON_VIEW;
	}
	
	
	@RequestMapping("/wms/outbound/json/SaveTM06.*")
	public String SaveTM06(HttpServletRequest request, Map model) throws SQLException{				
		DataMap map = (DataMap)request.getAttribute(CommonConfig.PARAM_ATT_KEY);
		
		Object data = outboundService.SaveTM06(map);
		
		model.put("data", data);
		
		return JSON_VIEW;
	
	}
	
	@RequestMapping("/wms/outbound/json/saveShpd.*")
	public String saveShpd(HttpServletRequest request, Map model) throws SQLException{				
		DataMap map = (DataMap)request.getAttribute(CommonConfig.PARAM_ATT_KEY);
		
		Object data = outboundService.saveShpd(map);
		
		model.put("data", data);
		
		return JSON_VIEW;
	}
	
	@RequestMapping("/wms/outbound/json/deleteOrder.*")
	public String deleteOrder(HttpServletRequest request, Map model) throws SQLException{				
		DataMap map = (DataMap)request.getAttribute(CommonConfig.PARAM_ATT_KEY);
		
		Object data = outboundService.deleteOrder(map);
		
		model.put("data", data);
		
		return JSON_VIEW;
	}
	
	@RequestMapping("/wms/outbound/json/dl04Procall.*")
	public String dl04Procall(HttpServletRequest request, Map model) throws SQLException{				
		DataMap map = (DataMap)request.getAttribute(CommonConfig.PARAM_ATT_KEY);
		
		Object data = outboundService.dl04Procall(map);
		
		model.put("data", data);
		
		return JSON_VIEW;
	}

	
	@RequestMapping("/wms/outbound/json/validateSendEcms.*")
	public String validateSendEcms(HttpServletRequest request, Map model) throws Exception{				
		DataMap map = (DataMap)request.getAttribute(CommonConfig.PARAM_ATT_KEY);
		
		String result = outboundService.validateSendEcms(map);
		
		model.put("data", result);
		
		return JSON_VIEW;
	}
	
	@RequestMapping("/wms/outbound/json/sendEcms.*")
	public String sendEcms(HttpServletRequest request, Map model) throws SQLException{				
		DataMap map = (DataMap)request.getAttribute(CommonConfig.PARAM_ATT_KEY);
		

		Object data = outboundService.sendEcms(map);
		
		model.put("data", data);
		
		return JSON_VIEW;
	}
	
	@RequestMapping("/wms/outbound/json/savePrtseq.*")
	public String savePrtseq(HttpServletRequest request, Map model) throws SQLException{				
		DataMap map = (DataMap)request.getAttribute(CommonConfig.PARAM_ATT_KEY);
		
		Object data = outboundService.savePrtseq(map);
		
		model.put("data", data);
		
		return JSON_VIEW;
	}
	
	@RequestMapping("/wms/outbound/json/savePrtseq2.*")
	public String savePrtseq2(HttpServletRequest request, Map model) throws SQLException{				
		DataMap map = (DataMap)request.getAttribute(CommonConfig.PARAM_ATT_KEY);
		
		Object data = outboundService.savePrtseq2(map);
		
		model.put("data", data);
		
		return JSON_VIEW;
	}
	
	@RequestMapping("/wms/outbound/json/saveDL04.*")
	public String saveDL04(HttpServletRequest request, Map model) throws SQLException{				
		DataMap map = (DataMap)request.getAttribute(CommonConfig.PARAM_ATT_KEY);
		
		Object data = outboundService.saveDL04(map);
		
		model.put("data", data);
		
		return JSON_VIEW;
	}
	
	@RequestMapping("/wms/outbound/json/saveDL04Sub.*")
	public String saveDL04Sub(HttpServletRequest request, Map model) throws SQLException{				
		DataMap map = (DataMap)request.getAttribute(CommonConfig.PARAM_ATT_KEY);
		
		Object data = outboundService.saveDL04Sub(map);
		
		model.put("data", data);
		
		return JSON_VIEW;
	}
	
	@RequestMapping("/wms/outbound/json/AssignDL04.*")
	public String AssignDL04(HttpServletRequest request, Map model) throws SQLException{				
		DataMap map = (DataMap)request.getAttribute(CommonConfig.PARAM_ATT_KEY);
		
		DataMap data = outboundService.AssignDL04(map);
		
		model.putAll(data);
		
		return JSON_VIEW;
	}
	
	@RequestMapping("/wms/outbound/json/CompleteDL04.*")
	public String CompleteDL04(HttpServletRequest request, Map model) throws SQLException{				
		DataMap map = (DataMap)request.getAttribute(CommonConfig.PARAM_ATT_KEY);
		
		Object data = outboundService.CompleteDL04(map);
		
		model.put("data", data);
		
		return JSON_VIEW;
	}
	
	@RequestMapping("/wms/outbound/json/UnallocateDL04.*")
	public String UnallocateDL04(HttpServletRequest request, Map model) throws SQLException{				
		DataMap map = (DataMap)request.getAttribute(CommonConfig.PARAM_ATT_KEY);
		
		Object data = outboundService.UnallocateDL04(map);
		
		model.put("data", data);
		
		return JSON_VIEW;
	}
	
	@RequestMapping("/wms/outbound/json/DL09CancelShipment.*")
	public String DL09CancelShipment(HttpServletRequest request, Map model) throws SQLException{				
		DataMap map = (DataMap)request.getAttribute(CommonConfig.PARAM_ATT_KEY);
		
		Object data = outboundService.DL09CancelShipment(map);
		
		model.put("data", data);
		
		return JSON_VIEW;
	}
	
	@RequestMapping("/wms/outbound/json/CompleteDL06.*")
	public String CompleteDL06(HttpServletRequest request, Map model) throws SQLException{				
		DataMap map = (DataMap)request.getAttribute(CommonConfig.PARAM_ATT_KEY);
		
		Object data = outboundService.CompleteDL06(map);
		
		model.put("data", data);
		
		return JSON_VIEW;
	}
	
	@RequestMapping("/wms/outbound/json/CompleteDL16.*")
	public String CompleteDL16(HttpServletRequest request, Map model) throws SQLException{				
		DataMap map = (DataMap)request.getAttribute(CommonConfig.PARAM_ATT_KEY);
		
		Object data = outboundService.CompleteDL16(map);
		
		model.put("data", data);
		
		return JSON_VIEW;
	}
	
	@RequestMapping("/wms/outbound/json/PickingCancelDL07.*")
	public String PickingCancelDL07(HttpServletRequest request, Map model) throws SQLException{				
		DataMap map = (DataMap)request.getAttribute(CommonConfig.PARAM_ATT_KEY);
		
		Object data = outboundService.PickingCancelDL07(map);
		
		model.put("data", data);
		
		return JSON_VIEW;
	}
	
	@RequestMapping("/wms/outbound/json/PickingCancelDL17.*")
	public String PickingCancelDL17(HttpServletRequest request, Map model) throws SQLException{				
		DataMap map = (DataMap)request.getAttribute(CommonConfig.PARAM_ATT_KEY);
		
		Object data = outboundService.PickingCancelDL17(map);
		
		model.put("data", data);
		
		return JSON_VIEW;
	}
	
	@RequestMapping("/wms/outbound/json/savePrtseqDL09.*")
	public String savePrtseqDL09(HttpServletRequest request, Map model) throws SQLException{				
		DataMap map = (DataMap)request.getAttribute(CommonConfig.PARAM_ATT_KEY);
		
		Object data = outboundService.savePrtseqDL09(map);
		
		model.put("data", data);
		
		return JSON_VIEW;
	}
	
	@RequestMapping("/wms/outbound/json/savePrtseqPT01.*")
	public String savePrtseqPT01(HttpServletRequest request, Map model) throws SQLException{				
		DataMap map = (DataMap)request.getAttribute(CommonConfig.PARAM_ATT_KEY);
		
		Object data = outboundService.savePrtseqPT01(map);
		
		model.put("data", data);
		
		return JSON_VIEW;
	}
	
	@RequestMapping("/wms/outbound/json/savePrtseqDL04.*")
	public String savePrtseqDL04(HttpServletRequest request, Map model) throws SQLException{				
		DataMap map = (DataMap)request.getAttribute(CommonConfig.PARAM_ATT_KEY);
		
		Object data = outboundService.savePrtseqDL04(map);
		
		model.put("data", data);
		
		return JSON_VIEW;
	}
	
	@RequestMapping("/wms/outbound/json/closingDL04.*")
	public String closingDL04(HttpServletRequest request, Map model) throws SQLException{				
		DataMap map = (DataMap)request.getAttribute(CommonConfig.PARAM_ATT_KEY);
		
		Object data = outboundService.closingDL04(map);
		
		model.put("data", data);
		
		return JSON_VIEW;
	}
}