package com.wms.controller;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.common.bean.CommonConfig;
import com.common.bean.CommonLabel;
import com.common.bean.DataMap;
import com.common.bean.UriInfo;
import com.common.bean.User;
import com.common.controller.BaseController;
import com.common.service.CommonService;
import com.common.bean.DataMap;

@Controller
public class WmsController extends BaseController {
	
	private static Logger log = Logger.getLogger(WmsController.class);

	@Autowired
	private CommonLabel commonLabel;	
	
	@Autowired
	private CommonService commonService;
	
	@RequestMapping("/wms/index/{page}.*")
	public String index(HttpServletRequest request, Map model, @PathVariable String page) throws SQLException{
		DataMap map = (DataMap)request.getAttribute(CommonConfig.PARAM_ATT_KEY);
		map.setModuleCommand("Wms", "WAHMACOMBO");
		
		List list = commonService.getList(map);
		
		model.put("WAHMACOMBO", list);
		
		map.setModuleCommand("Common", "COMCOMBO");
		map.put("CODE", "LANGKY");
		
		List list1 = commonService.getList(map);
		
		model.put("LANGKY", list1);
		
		map.setModuleCommand("Common", "LOGINMSG");
		List list2 = commonService.getList(map);
		
		model.put("MSG", list2);
		
		return "/wms/"+page;
	}

	@RequestMapping("/wms/common/json/leftMenu.*")
	public String leftMenu(HttpServletRequest request, Map model) throws SQLException{
		String langky = request.getSession().getAttribute(CommonConfig.SES_USER_LANGUAGE_KEY).toString();
		String userid = request.getSession().getAttribute(CommonConfig.SES_USER_ID_KEY).toString();
		
		DataMap map = new DataMap("Common", "MENUTREE");
		map.put("LANGKY", langky);
		map.put("USERID", userid);
		
		List<DataMap> list = commonService.getList(map);
		
		model.put("list", list);
		
		return "/wms/left";
	}
	
	@RequestMapping("/wms/{page}.*")
	public String page(@PathVariable String page) throws SQLException{
		
		return "/wms/"+page;
	}
	
	@RequestMapping("/wms/{module}/{page}.*")
	public String mpage(@PathVariable String module, @PathVariable String page) throws SQLException{
		
		return "/wms/"+module+"/"+page;
	}
	
	@RequestMapping("/wms/common/json/getDocSeq.*")
	public String getDocSeq(HttpServletRequest request, Map model) throws SQLException{				
		DataMap map = (DataMap)request.getAttribute(CommonConfig.PARAM_ATT_KEY);
		map.setModuleCommand("Common", "DOCUSEQ");
		
		Object docseq = commonService.insert(map);
		
		model.put("DOCNO", docseq);
		
		return JSON_VIEW;
	}
	
	@RequestMapping("/wms/common/json/changeWareky.*")
	public String login(HttpServletRequest request, Map model) throws SQLException{
		DataMap map = (DataMap)request.getAttribute(CommonConfig.PARAM_ATT_KEY);
		map.setModuleCommand("Wms", "OWNER");
		
		DataMap data = (DataMap)commonService.getMap(map);
		
		if(data.containsKey("OWNER")){
			User user = (User)request.getSession().getAttribute(CommonConfig.SES_USER_OBJECT_KEY);
			user.setOwner(data.getString("OWNER"));
			request.getSession().setAttribute(CommonConfig.SES_USER_WHAREHOUSE_KEY, map.getString("WAREKY"));
			request.getSession().setAttribute(CommonConfig.SES_USER_OWNER_KEY, user.getOwner());
			
			model.put("data", "S");
		}else{
			model.put("data", "F");
		}	
		
		return JSON_VIEW;
	}
	
	@RequestMapping("/wms/common/common_ezprint.*")
	public String ezpage(HttpServletRequest request, Map model) throws SQLException{
		DataMap map = (DataMap)request.getAttribute(CommonConfig.PARAM_ATT_KEY);
		UriInfo uriInfo = (UriInfo)request.getAttribute(CommonConfig.REQUEST_URI_INFO_KEY);
		model.put("filename", map.get("filename"));
		model.put("andvalue", map.get("andvalue"));
		model.put("width", map.get("width"));
		model.put("height", map.get("height"));
		model.put("url", uriInfo.getUrl());
		return "/wms/common/common_ezprint";
	}
	
	@RequestMapping("/wms/common/userinfo.*")
	public String userInfo(HttpSession session, HttpServletRequest request, Map model) throws SQLException{
		DataMap map = (DataMap)request.getAttribute(CommonConfig.PARAM_ATT_KEY);
		
		
		Object obj = session.getAttribute(CommonConfig.SES_USER_INFO_KEY);
		DataMap data = null;
		
		if(obj != null){
			data = (DataMap)obj;
		}
		
		model.put("data", data);
		
		return JSON_VIEW;
	}
}