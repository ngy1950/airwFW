package com.wms.controller;

import java.sql.SQLException;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.common.bean.CommonConfig;
import com.common.bean.DataMap;
import com.common.controller.BaseController;
import com.common.service.SystemService;

@Controller
public class WmsSystemController extends BaseController {
	
	private static Logger log = Logger.getLogger(WmsSystemController.class);
	
	@Autowired
	private SystemService systemservice;
	
	@RequestMapping("/wms/system/json/UI01.*")
	public String saveUi01(HttpServletRequest request, Map model) throws SQLException{				
		DataMap map = (DataMap)request.getAttribute(CommonConfig.PARAM_ATT_KEY);
		
		Object data = systemservice.saveUi01(map);
		
		model.put("data", data);
		
		return JSON_VIEW;
	}
	
	@RequestMapping("/wms/system/json/YHU01.*")
	public String saveYhu01(HttpServletRequest request, Map model) throws SQLException{				
		DataMap map = (DataMap)request.getAttribute(CommonConfig.PARAM_ATT_KEY);
		
		Object data = systemservice.saveYhu01(map);
		
		model.put("data", data);
		
		return JSON_VIEW;
	}
/*	
	@RequestMapping("/wms/system/json/YHI01.*")
	public String saveYhi01(HttpServletRequest request, Map model) throws SQLException{				
		DataMap map = (DataMap)request.getAttribute(CommonConfig.PARAM_ATT_KEY);
		
		Object data = systemservice.saveYhi01(map);
		
		model.put("data", data);
		
		return JSON_VIEW;
	}*/
	
	@RequestMapping("/wms/system/json/UR01.*")
	public String saveUr01(HttpServletRequest request, Map model) throws SQLException{				
		DataMap map = (DataMap)request.getAttribute(CommonConfig.PARAM_ATT_KEY);
		
		Object data = systemservice.saveUr01(map);
		
		model.put("data", data);
		
		return JSON_VIEW;
	}
	
	@RequestMapping("/wms/system/json/YS01.*")
	public String saveYs01(HttpServletRequest request, Map model) throws SQLException{				
		DataMap map = (DataMap)request.getAttribute(CommonConfig.PARAM_ATT_KEY);
		
		Object data = systemservice.saveYs01(map);
		
		model.put("data", data);
		
		return JSON_VIEW;
	}
	
	@RequestMapping("/wms/system/json/delYS01.*")
	public String delYs01(HttpServletRequest request, Map model) throws SQLException{				
		DataMap map = (DataMap)request.getAttribute(CommonConfig.PARAM_ATT_KEY);
		
		Object data = systemservice.delYs01(map);
		
		model.put("data", data);
		
		return JSON_VIEW;
	}
	
	@RequestMapping("/wms/system/json/delYH01.*")
	public String delYH01(HttpServletRequest request, Map model) throws SQLException{				
		DataMap map = (DataMap)request.getAttribute(CommonConfig.PARAM_ATT_KEY);
		
		Object data = systemservice.delYH01(map);
		
		model.put("data", data);
		
		return JSON_VIEW;
	}
	
	
}