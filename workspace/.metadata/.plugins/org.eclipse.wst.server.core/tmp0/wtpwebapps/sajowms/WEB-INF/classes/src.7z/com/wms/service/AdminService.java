package com.wms.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.common.bean.CommonConfig;
import com.common.bean.DataMap;
import com.common.dao.CommonDAO;
import com.common.bean.DataMap;
import com.common.util.Util;

@Service
public class AdminService {

	private static Logger log = Logger.getLogger(AdminService.class);

	@Autowired
	private Util util;
	
	@Autowired
	public CommonDAO commonDao;

	@Transactional
	public String validationSK01(DataMap map) throws SQLException {
		
		String result = "OK";
		List<DataMap> list = map.getList("list");
		
		String validationSql = "";
		String key = map.get("key").toString();
		if( map.containsKey("key") ){
			validationSql = util.urlCreateValidationSql(map, key);
			map.put(CommonConfig.VALIDATION_SQL_KEY, validationSql);
			map.setModuleCommand("WmsAdmin", "SKUMA");
						
			List<DataMap> vList = commonDao.getValidation(map);
			
			DataMap rsMap = new DataMap();
			
			for(int j = 0; j < vList.size(); j++){
				rsMap = vList.get(j);
					
				if( !rsMap.getString("MSG").equals("OK") ){
					
					result = rsMap.getString("MSG");
					break;
				}
			}
		}
	
		return result;
	}
	
	@Transactional
	public String validationSP01(DataMap map) throws SQLException {
		String result = "OK";
		List<DataMap> list = map.getList("list");
		
		System.out.println("list > " + list);
		
		String validationSql = "";
		String key = map.get("key").toString();
		if( map.containsKey("key") ){
			validationSql = util.urlCreateValidationSql(map, key);
			map.put(CommonConfig.VALIDATION_SQL_KEY, validationSql);
			map.setModuleCommand("WmsAdmin", "PAKMA");
						
			List<DataMap> vList = commonDao.getValidation(map);
			
			System.out.println("vList > " + vList);
			DataMap row = new DataMap();
			DataMap rsMap = new DataMap();
			String rowState = row.getString(CommonConfig.GRID_ROW_STATE_ATT);
			System.out.println("rowState > " + rowState);
			
			for(int j = 0; j < vList.size(); j++){
				rsMap = vList.get(j);
					
				if( !rsMap.getString("MSG").equals("OK") ){
					
					result = rsMap.getString("MSG");
					break;
				}
			}
		}
	
		return result;
	}
	
	/*@Transactional
	public int saveSM01(DataMap map) throws SQLException {
		List<DataMap> head = map.getList("head");
		List<DataMap> list = map.getList("list");
		
		DataMap headRow = new DataMap();
		DataMap row = new DataMap();
		String rowState = "";
		int count = 0;
		
		for(int i=0;i<head.size();i++){
			headRow = head.get(i).getMap("map");
			rowState = headRow.getString(CommonConfig.GRID_ROW_STATE_ATT);
			headRow.setModuleCommand("WmsAdmin", "MEASH");
			headRow.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
			
			if( rowState.charAt(0)  == 'R' ){
				continue;
			}else if( rowState.charAt(0)  == 'C' ){
				commonDao.insert(headRow);
			}else if( rowState.charAt(0)  == 'U' ){
				commonDao.delete(headRow);
				commonDao.insert(headRow);
			}else if( rowState.charAt(0)  == 'D' ){
				commonDao.delete(headRow);
				row = head.get(i).getMap("map");
				row.setModuleCommand("WmsAdmin", "MEASHSubAll");
				row.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
				commonDao.delete(row);
			}
			count++;
		}
		
		for(int j=0;j<list.size();j++){
			row = list.get(j).getMap("map");
			rowState = row.getString(CommonConfig.GRID_ROW_STATE_ATT);
			row.setModuleCommand("WmsAdmin", "MEASHSub");
			row.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
			if( rowState.charAt(0)  == 'R' ){
				continue;
			}else if( rowState.charAt(0)  == 'C' ){
				commonDao.insert(row);
			}else if( rowState.charAt(0)  == 'U' ){
				commonDao.update(row);
			}else if( rowState.charAt(0)  == 'D' ){
				commonDao.delete(row);
			}
			count++;
		}
		return count;
	}
	*/
	@Transactional
	public String saveSM01(DataMap map) throws SQLException {
		List<DataMap> head = map.getList("head");
		List<DataMap> list = map.getList("list");

		DataMap headRow = new DataMap();
		DataMap row = new DataMap();

		String result = "HHT_T0008";

		for (int i = 0; i < head.size(); i++) {
			headRow = head.get(i).getMap("map");
			headRow.setModuleCommand("WmsAdmin", "MEASH");
			headRow.put(CommonConfig.SES_USER_ID_KEY,
					map.get(CommonConfig.SES_USER_ID_KEY));

			if (headRow.get("STATUS").toString().equals("R")) {
				continue;
			} else if (headRow.get("STATUS").toString().equals("C")) {
				commonDao.insert(headRow);
			} else if (headRow.get("STATUS").toString().equals("U")) {
				commonDao.delete(headRow);
				commonDao.insert(headRow);
			} else {
				commonDao.delete(headRow);
				
				row = head.get(i).getMap("map");
				row.setModuleCommand("WmsAdmin", "MEASHSubAll");
				row.put(CommonConfig.SES_USER_ID_KEY,
						map.get(CommonConfig.SES_USER_ID_KEY));
				
				commonDao.delete(row);
			}
		}

		for (int j = 0; j < list.size(); j++) {
			row = list.get(j).getMap("map");
			row.setModuleCommand("WmsAdmin", "MEASHSub");
			row.put(CommonConfig.SES_USER_ID_KEY,
					map.get(CommonConfig.SES_USER_ID_KEY));
			if (row.get("STATUS").toString().equals("R")) {
				continue;
			} else if (row.get("STATUS").toString().equals("C")) {
				commonDao.insert(row);
			} else if (row.get("STATUS").toString().equals("U")) {
				commonDao.delete(row);
				commonDao.insert(row);
			} else {
				commonDao.delete(row);
			}
		}
		return result;
	}

	
	@Transactional
	public int saveSP01(DataMap map) throws SQLException {
		List<DataMap> list = map.getList("list");
		List<DataMap> head = map.getList("head");
		
		DataMap headRow = new DataMap();
		DataMap row = new DataMap();
		
		int count = 0;
		for(int i=0;i<list.size();i++){			
			row = list.get(i).getMap("map");			
			//row.append(list.get(i).getMap("map"));			
			row.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
			row.setModuleCommand("WmsAdmin", "PAKMA");
			
			String rowState = row.getString(CommonConfig.GRID_ROW_STATE_ATT);
			switch(rowState.charAt(0)){
				case 'C':
					commonDao.insert(row);
					break;
				case 'U':
					commonDao.update(row);
					break;
				case 'D':
					commonDao.delete(row);
					break;
			}
			count++;
		}
		
		for(int i=0;i<head.size();i++){			
			headRow = head.get(i).getMap("map");			
			//row.append(list.get(i).getMap("map"));			
			headRow.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
			headRow.setModuleCommand("WmsAdmin", "PAKMAHEAD");
			
			String rowState = headRow.getString(CommonConfig.GRID_ROW_STATE_ATT);
			switch(rowState.charAt(0)){
				case 'D':
					commonDao.delete(headRow);
					break;
			}
			count++;
		}
		return count;
	}
	
	
	
	@Transactional
	public int saveSK01(DataMap map) throws SQLException {
		
		List<DataMap> head = map.getList("head");
		
		DataMap row;
		String rowState = "";
		int count = 0;
		
		for(int i = 0; i< head.size(); i++){
			
			row = head.get(i).getMap("map");
			rowState = row.getString(CommonConfig.GRID_ROW_STATE_ATT);
			
			log.debug("status::::::::::::::::::::::::"+row.getString("GRowState"));
			
			if( rowState.charAt(0)  == 'U' ){
				
				row.setModuleCommand("WmsAdmin", "SKUWC");
				row.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
				commonDao.update(row);
				
				row.setModuleCommand("WmsAdmin", "SKUMA");
				row.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
				commonDao.update(row);
				
			}else	if( rowState.charAt(0)  == 'C' ){	
				log.debug("::::::::::::::insert::::::::::::::::::::::");
				
				row.setModuleCommand("WmsAdmin", "SKUWC");
				row.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
				commonDao.insert(row);
				
				row.setModuleCommand("WmsAdmin", "SKUMA");
				row.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
				commonDao.insert(row);
				
			}else	if( rowState.charAt(0)  == 'R' ){	
				
			}else	if( rowState.charAt(0)  == 'D' ){
				row.setModuleCommand("WmsAdmin", "SKUWC");
				row.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
				commonDao.delete(row);
				
				row.setModuleCommand("WmsAdmin", "SKUMA");
				row.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
				commonDao.delete(row);
			}
			count++;
		}
		return count;
	}
	
	

	@Transactional
	public String saveCC01(DataMap map) throws SQLException {
		List<DataMap> head = map.getList("head");
		List<DataMap> list = map.getList("list");

		DataMap headRow = new DataMap();
		DataMap row = new DataMap();

		String result = "HHT_T0008";

		for (int i = 0; i < head.size(); i++) {
			headRow = head.get(i).getMap("map");
			headRow.setModuleCommand("WmsAdmin", "CC01");
			headRow.put(CommonConfig.SES_USER_ID_KEY,
					map.get(CommonConfig.SES_USER_ID_KEY));

			if (headRow.get("STATUS").toString().equals("R")) {
				continue;
			} else if (headRow.get("STATUS").toString().equals("C")) {
				commonDao.insert(headRow);
			} else if (headRow.get("STATUS").toString().equals("U")) {
				commonDao.delete(headRow);
				commonDao.insert(headRow);
			} else {
				commonDao.delete(headRow);
				row = head.get(i).getMap("map");
				row.setModuleCommand("WmsAdmin", "CC01Sub");
				row.put(CommonConfig.SES_USER_ID_KEY,
						map.get(CommonConfig.SES_USER_ID_KEY));
				commonDao.delete(row);
			}
		}

		for (int j = 0; j < list.size(); j++) {
			row = list.get(j).getMap("map");
			row.setModuleCommand("WmsAdmin", "CC01Sub");
			row.put(CommonConfig.SES_USER_ID_KEY,
					map.get(CommonConfig.SES_USER_ID_KEY));
			if (row.get("STATUS").toString().equals("R")) {
				continue;
			} else if (row.get("STATUS").toString().equals("C")) {
				commonDao.insert(row);
			} else if (row.get("STATUS").toString().equals("U")) {
				commonDao.delete(row);
				commonDao.insert(row);
			} else {
				commonDao.delete(row);
			}
		}
		return result;
	}

	@Transactional
	public String saveTA01(DataMap map) throws SQLException {
		List<DataMap> head = map.getList("head");
		List<DataMap> list = map.getList("list");

		DataMap headRow = new DataMap();
		DataMap row = new DataMap();

		String result = "HHT_T0008";

		for (int i = 0; i < head.size(); i++) {
			headRow = head.get(i).getMap("map");
			headRow.setModuleCommand("WmsAdmin", "TA01");
			headRow.put(CommonConfig.SES_USER_ID_KEY,
					map.get(CommonConfig.SES_USER_ID_KEY));

			if (headRow.get("STATUS").toString().equals("R")) {
				continue;
			} else if (headRow.get("STATUS").toString().equals("C")) {
				commonDao.insert(headRow);
			} else if (headRow.get("STATUS").toString().equals("U")) {
				commonDao.delete(headRow);
				commonDao.insert(headRow);
			} else {
				commonDao.delete(headRow);
				
				row = head.get(i).getMap("map");
				row.setModuleCommand("WmsAdmin", "TA01Sub");
				row.put(CommonConfig.SES_USER_ID_KEY,
						map.get(CommonConfig.SES_USER_ID_KEY));
				
				commonDao.delete(row);
			}
		}

		for (int j = 0; j < list.size(); j++) {
			row = list.get(j).getMap("map");
			row.setModuleCommand("WmsAdmin", "TA01Sub");
			row.put(CommonConfig.SES_USER_ID_KEY,
					map.get(CommonConfig.SES_USER_ID_KEY));
			if (row.get("STATUS").toString().equals("R")) {
				continue;
			} else if (row.get("STATUS").toString().equals("C")) {
				commonDao.insert(row);
			} else if (row.get("STATUS").toString().equals("U")) {
				commonDao.delete(row);
				commonDao.insert(row);
			} else {
				commonDao.delete(row);
			}
		}
		return result;
	}


	@Transactional
	public String saveTP01(DataMap map) throws SQLException {
		List<DataMap> head = map.getList("head");
		List<DataMap> list = map.getList("list");

		DataMap headRow = new DataMap();
		DataMap row = new DataMap();

		String result = "COMMON_M0007"; 

		for (int i = 0; i < head.size(); i++) {
			headRow = head.get(i).getMap("map");
			headRow.setModuleCommand("WmsAdmin", "TP01");
			headRow.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));

			if (headRow.get("STATUS").toString().equals("R")) {
				continue;
			} else if (headRow.get("STATUS").toString().equals("C")) {
				commonDao.insert(headRow);
			} else if (headRow.get("STATUS").toString().equals("U")) {
				commonDao.delete(headRow);
				commonDao.insert(headRow);
			} else {
				commonDao.delete(headRow);
				
				row = head.get(i).getMap("map");
				row.setModuleCommand("WmsAdmin", "TP01Sub");
				row.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
				
				commonDao.delete(row);
			}
		}

		for (int j = 0; j < list.size(); j++) {
			row = list.get(j).getMap("map");
			row.setModuleCommand("WmsAdmin", "TP01Sub");
			row.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
			if (row.get("STATUS").toString().equals("R")) {
				continue;
			} else if (row.get("STATUS").toString().equals("C")) {
				commonDao.insert(row);
			} else if (row.get("STATUS").toString().equals("U")) {
				commonDao.delete(row);
				commonDao.insert(row);
			} else {
				commonDao.delete(row);
			}
		}
		return result;
	}

	
	@Transactional
	public int saveNR01(DataMap map) throws SQLException {
		int count = 0;

		DataMap list = map.getMap("list").getMap("map");
		if(map.get("flag").equals("U")){
			list.setModuleCommand("WmsAdmin", "NR01UP");
		}else{
			list.setModuleCommand("WmsAdmin", "NR01I");
		}
		
		count += commonDao.update(list);

		return count;
	}
	
	@Transactional
	public int saveTF01(DataMap map) throws SQLException {
		int count = 0;
		DataMap head = map.getMap("head").getMap("map");
		DataMap list = map.getMap("list").getMap("map");
		head.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
		String status = map.getString("STATUS");
		/*System.out.println("+++++++++++++"+head);
		System.out.println("+++++++++++++"+list);
		System.out.println("status :  "+status);*/
		
		
		if("U".equals(status)){
			head.setModuleCommand("WmsAdmin", "TF01I");
			commonDao.delete(head);
			head.setModuleCommand("WmsAdmin", "TF01SubI");
			commonDao.delete(head);
			status = "I";
		}
	    if("I".equals(status)){
			head.setModuleCommand("WmsAdmin", "TF01I");
			commonDao.update(head);
			
			DataMap row = new DataMap();
			String rowStr = ""; 
			List keyList = new ArrayList();
			keyList.add("LOTA01");
			keyList.add("LOTA02");
			keyList.add("LOTA03");
			keyList.add("LOTA11LSCK");
			/*keyList.add("LOTA11TSCK");*/
			keyList.add("LOTA11");
			keyList.add("AREAKY");
			keyList.add("ZONEKY");
			keyList.add("LOCAKY");
			keyList.add("TKZONE");
			keyList.add("STKQTY");
			
			List<DataMap> itemList = null;
			int number = 0;
 			for(int i=0; i<keyList.size(); i++){
				row = new DataMap();
				row.setModuleCommand("WmsAdmin", "TF01SubI");
				String keyname = keyList.get(i).toString();
				rowStr = list.getString(keyname);
				if(keyname.equals("LOTA11LSCK")){
					String lsck = list.getString("LOTA11LSCK");
					String tsck = list.getString("LOTA11TSCK");
					if(tsck.equals("V")&&lsck.equals("V")){
						row.put("RNGVOP", "BW");
						row.put("RNGVMI", "1");
						row.put("RNGVMX", "0");
					}else if(tsck.equals("V") && lsck.equals("")){
						row.put("RNGVOP", "LK");
						row.put("RNGVMI", "0");
					}else if(tsck.equals("") && lsck.equals("V")){
						row.put("RNGVOP", "LK");
						row.put("RNGVMI", "1");
					}else{
						continue;
					}
					
					row.put("RNGVMX", " ");
					row.put("DBFILD", "LOTA11");
				}else if(keyname.equals("LOTA11")){
					if(rowStr.equals("") || rowStr.equals(" ")){
						continue;
					}
					row.put("RNGVOP", "GT");
					row.put("DBFILD", keyname.toLowerCase());
					row.put("RNGVMI", rowStr);
					row.put("RNGVMX", " ");
				}else if(keyname.equals("TKZONE") || keyname.equals("STKQTY")){
					if(rowStr.equals("") || rowStr.equals(" ")){
						continue;
					}
					row.put("RNGVOP", "EQ");
					row.put("DBFILD", keyname.toLowerCase());
					row.put("RNGVMI", rowStr);
					row.put("RNGVMX", " ");
				}else{
					row.put("RNGVOP", "EQ");
					row.put("DBFILD", keyname.toLowerCase());
					row.put("RNGVMI", rowStr);
					row.put("RNGVMX", " ");
				}
				row.put("RNGVIE", "signIn");
				row.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
				row.put("WAREKY",head.getString("WAREKY"));
				row.put("LOTRKY",head.getString("LOTRKY"));
				if(
						keyname.equals("LOTA01")
						||keyname.equals("LOTA02")
						||keyname.equals("LOTA03")
						||keyname.equals("AREAKY")
						||keyname.equals("ZONEKY")
						||keyname.equals("LOCAKY")
				){
					itemList = list.getList(keyname);
					System.out.println("itemList size() >>"+itemList.size());
					for(int y=0; y<itemList.size(); y++){
						DataMap itemMap = itemList.get(y).getMap("map");
						String data = itemMap.get("DATA").toString();
						row.put("ITEMNO",number++);
						if(data.trim().length() > 0){
							String oper = itemMap.get("OPER").toString();
							if(oper.equals("E")){
								row.put("RNGVOP", "EQ");
							}else if(oper.equals("N")){
								row.put("RNGVOP", "NE");
							}else if(oper.equals("LT")){
								row.put("RNGVOP", "LT");
							}else if(oper.equals("GT")){
								row.put("RNGVOP", "GT");
							}else if(oper.equals("LE")){
								row.put("RNGVOP", "LE");
							}else if(oper.equals("GE")){
								row.put("RNGVOP", "GE");
							}
							row.put("RNGVMI", itemMap.get("DATA"));
							row.put("RNGVMX", " ");
						}else{
							String oper = itemMap.get("OPER").toString();
							if(oper.equals("N")){
								row.put("RNGVOP", "NB");
							}else{
								row.put("RNGVOP", "BW");	
							}
							row.put("RNGVMI", itemMap.get("FROM"));
							row.put("RNGVMX", itemMap.get("TO"));
						}
						count += commonDao.update(row);
					}
				}else{
					System.out.println(i + " rowStr : "+row);
					row.put("ITEMNO",number++);
					count += commonDao.update(row);
				}
			}
		}
		System.out.println("count:"+count);
		return count;
	}	
	
	@Transactional
	public int delTF01(DataMap map) throws SQLException {
		int count=0;
		DataMap head = map.getMap("head").getMap("map");
		head.setModuleCommand("WmsAdmin", "TF01I");
		count += commonDao.delete(head);
		head.setModuleCommand("WmsAdmin", "TF01SubI");
		count += commonDao.delete(head);
		return count;
	}
	@Transactional
	public int delNR01(DataMap map) throws SQLException {
		int count = 0;

		DataMap list = map.getMap("list").getMap("map");
		list.setModuleCommand("WmsAdmin", "NR01DEL");
		
		count += commonDao.delete(list);

		return count;
	}
	@Transactional
	public int saveTsu01(DataMap map) throws SQLException {
		int count = 0;
		DataMap list = map.getMap("list").getMap("map");
		List<DataMap> itemList = map.getList("itemList");
		list.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
		list.put(CommonConfig.SES_USER_LANGUAGE_KEY, map.get(CommonConfig.SES_USER_LANGUAGE_KEY));
		String status = map.getString("STATUS");
		System.out.println("+++++++++++++"+list);
		System.out.println("+++++++++++++"+itemList);
		System.out.println("status :  "+status);
		if("U".equals(status)){
			list.setModuleCommand("WmsAdmin", "STSRHTOP");
			commonDao.delete(list);
			list.setModuleCommand("WmsAdmin", "STSRIDEL");
			commonDao.delete(list);
			status = "I";
		}
		if("I".equals(status)){
			String rowStr = ""; 
			list.setModuleCommand("WmsAdmin", "TS01I");
			commonDao.update(list);
			
			DataMap row = new DataMap();
			for (int i = 0; i < itemList.size(); i++){
				row = itemList.get(i).getMap("map");
				rowStr = row.getString("ACTVAT");
				row.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
				row.put(CommonConfig.SES_USER_LANGUAGE_KEY, map.get(CommonConfig.SES_USER_LANGUAGE_KEY));
			
				row.setModuleCommand("WmsAdmin","TS01SubI");
		
				count+=commonDao.update(row);
			}
		}
			
		return count;
	}
	
	@Transactional
	public int sendSynch(DataMap map) throws SQLException {
		//List<DataMap> list = map.getList("list");
		int count = 0;
		map.setModuleCommand("WmsAdmin", "sendSynch");
		commonDao.getMap(map);

		return count;
	}
	
	@Transactional
	public int sendSynch2(DataMap map) throws SQLException {
		//List<DataMap> list = map.getList("list");
		int count = 0;
		map.setModuleCommand("WmsAdmin", "sendSynch2");
		commonDao.getMap(map);

		return count;
	}
	
	@Transactional
	public String validationSA01(DataMap map) throws SQLException {
		String result = "OK";
		List<DataMap> list = map.getList("list");
		
		String validationSql = "";
		String key = map.get("key").toString();
		if( map.containsKey("key") ){
			validationSql = util.urlCreateValidationSql(map, key);
			map.put(CommonConfig.VALIDATION_SQL_KEY, validationSql);
			map.setModuleCommand("WmsAdmin", "SA01VAL");
						
			List<DataMap> vList = commonDao.getValidation(map);
			
			DataMap rsMap = new DataMap();
			
			for(int j = 0; j < vList.size(); j++){
				rsMap = vList.get(j);
				if( !rsMap.getString("MSG").equals("OK") ){
					result = rsMap.getString("MSG");
					break;
				}
			}
		}
		return result;
	}
	
	@Transactional
	public int saveSK03(DataMap map) throws SQLException {
		List<DataMap> list = map.getList("list");
		int count = 0;
		
		DataMap row;
		String rowState = "";
		for(int i=0;i<list.size();i++){
			row = list.get(i).getMap("map");
			rowState = row.getString(CommonConfig.GRID_ROW_STATE_ATT);
			
			if( rowState.charAt(0)  == 'U' ){
				row.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
				row.put(CommonConfig.SES_USER_OWNER_KEY, map.get(CommonConfig.SES_USER_OWNER_KEY));
				row.put(CommonConfig.SES_USER_WHAREHOUSE_KEY, map.get(CommonConfig.SES_USER_WHAREHOUSE_KEY));
				commonDao.update("WmsAdmin.SK03SKU", row);
			}else if( rowState.charAt(0)  == 'C' ){
				row.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
				row.put(CommonConfig.SES_USER_OWNER_KEY, map.get(CommonConfig.SES_USER_OWNER_KEY));
				row.put(CommonConfig.SES_USER_WHAREHOUSE_KEY, map.get(CommonConfig.SES_USER_WHAREHOUSE_KEY));
				commonDao.insert("WmsAdmin.SKUMA", row);
			}else if( rowState.charAt(0)  == 'D' ){
				row.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
				row.put(CommonConfig.SES_USER_OWNER_KEY, map.get(CommonConfig.SES_USER_OWNER_KEY));
				row.put(CommonConfig.SES_USER_WHAREHOUSE_KEY, map.get(CommonConfig.SES_USER_WHAREHOUSE_KEY));
				commonDao.delete("WmsAdmin.SKUMA", row);
			}
			
			count ++;
		}
		return count;
	}
	
	@Transactional
	public int updateIF01(DataMap map) throws SQLException {
		DataMap resultMap = new DataMap();
		int opt = map.getInt("num");
		String credat = map.getString("CREDAT").replace(".", "");
		
		int count = 0;
		
		map.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
		map.put(CommonConfig.SES_USER_OWNER_KEY, map.get(CommonConfig.SES_USER_OWNER_KEY));
		map.put(CommonConfig.SES_USER_WHAREHOUSE_KEY, map.get(CommonConfig.SES_USER_WHAREHOUSE_KEY));
		map.setModuleCommand("Erpif", "IF01_0"+opt);
		map.put("CREDAT", credat);
		
		commonDao.update(map);
		count ++;
		
		return count;
	}
	
	@Transactional
	public int checkIF01(DataMap map) throws SQLException {
		DataMap resultMap = new DataMap();
		int opt = map.getInt("num");
		String credat = map.getString("CREDAT").replace(".", "");
		
		int count = 0;
		
		map.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
		map.put(CommonConfig.SES_USER_OWNER_KEY, map.get(CommonConfig.SES_USER_OWNER_KEY));
		map.put(CommonConfig.SES_USER_WHAREHOUSE_KEY, map.get(CommonConfig.SES_USER_WHAREHOUSE_KEY));
		map.setModuleCommand("Erpif", "IF01CHK_0"+opt);
		map.put("CREDAT", credat);
		
		commonDao.update(map);
		count ++;
		
		return count;
	}
	

	@Transactional
	public String saveMr01(DataMap map) throws Exception {
		
		List<DataMap> list = map.getList("list");
		
		StringBuffer sb = new StringBuffer();
		for(DataMap item : list){
			if(sb.length() > 0)
				sb.append(" UNION ALL\n ");
			sb.append(" SELECT '").append(item.getMap("map").get("WAREKY")).append("' AS WAREKY, ");
			sb.append("        '").append(item.getMap("map").get("LSTOTY")).append("' AS LSTOTY, ");
			sb.append("        '").append(item.getMap("map").get("ZONEKY")).append("' AS ZONEKY, ");
			sb.append("        '").append(item.getMap("map").get("AREAKY")).append("' AS AREAKY FROM DUAL ");
		}	
		map.setModuleCommand("WmsAdmin", "STORY"); // 쿼리키값 넣을것
		map.put("APPEND_QUERY", sb.toString());
		List<DataMap> validList = commonDao.getValidation(map);
		if(validList.size() > 0){
			DataMap valid = validList.get(0);
			return valid.getString("RESULTMSG");
		}	
		return "OK";
	}
	
	
}