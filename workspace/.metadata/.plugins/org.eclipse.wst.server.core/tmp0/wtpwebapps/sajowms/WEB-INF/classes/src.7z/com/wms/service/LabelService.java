package com.wms.service;

import java.sql.SQLException;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.common.bean.CommonConfig;
import com.common.bean.DataMap;
import com.common.dao.CommonDAO;
import com.common.bean.DataMap;
import com.common.util.Util;

@Service
public class LabelService {

	private static Logger log = Logger.getLogger(LabelService.class);

	
	@Autowired
	public CommonDAO commonDao;

	@Transactional
	public String saveLB01(DataMap map) throws SQLException {
		//DataMap param = new DataMap();
		
		String result = "";
			//row.append(list.get(i).getMap("map"));			
			map.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
			map.setModuleCommand("WmsLabel", "LB01");

			commonDao.insert(map);
			
			DataMap temp = new DataMap();
			
			temp.setModuleCommand("WmsLabel", "LB01PRINT");
				
			List<DataMap> item = commonDao.getList(temp);
			//log.debug("item : " + item);
			result = item.get(0).getString("REFDKY");
			
			//log.debug("result : " + result);
		return result;
	}
}