package com.wms.service;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.CharacterIterator;
import java.text.SimpleDateFormat;
import java.text.StringCharacterIterator;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.common.bean.CommonConfig;
import com.common.bean.DataMap;
import com.common.dao.CommonDAO;
import com.common.bean.DataMap;
import com.common.util.StringUtility;
import com.common.util.Util;
import com.ibatis.sqlmap.client.SqlMapClient;
import com.ibatis.sqlmap.client.SqlMapSession;
import com.wms.controller.WmsController;

@Service
public class OutboundService {

	private static Logger log = Logger.getLogger(OutboundService.class);
	
	@Autowired
	private Util util;
	
	@Autowired
	public CommonDAO commonDao;
	
	@Autowired
	public WmsService wmsService;
	
	@Autowired
	@Qualifier("sqlMapClient")
	SqlMapClient sqlMapClient;
	
	
	public static boolean isNull(String value) {
		return (value == null);
	}
	
	public static boolean isEmpty(String value) {
		return (isNull(value) || value.trim().length() == 0);
	}
	
	public static boolean isNotEmpty(String value) {
		return isEmpty(value) ? false : true;
	}
	
	public static String leftPad(String stringToPad, String padder, int size) {
		StringBuffer strb;
		StringCharacterIterator sci;

		if (padder.length() == 0)
			return stringToPad;

		if (isNull(stringToPad)) {
			char[] t = new char[size];
			for (int i = 0; i < t.length; i++)
				t[i] = padder.charAt(0);

			stringToPad = String.valueOf(t);
		}

		strb = new StringBuffer(size);
		sci = new StringCharacterIterator(padder);

		while (strb.length() < (size - stringToPad.length()))
			for (char ch = sci.first(); ch != CharacterIterator.DONE; ch = sci.next())
				if (strb.length() < size - stringToPad.length())
					strb.insert(strb.length(), String.valueOf(ch));
		return strb.append(stringToPad).toString();
	}
	
	
	
	
	
	
	
	
	@Transactional
	public DataMap saveGr01(DataMap map) throws SQLException {
		List<DataMap> head = map.getList("head");
		List<DataMap> selectList = new ArrayList<DataMap>();
		if( map.get("list") != null && !map.get("list").equals("")){
			selectList = map.getList("list");
		}
		String headAsndky = map.get("headAsndky").toString();
		
		int count = 0;
		int itemCount = 0;
		
		DataMap row;
		DataMap itemRow;
		
		List docNumList = new ArrayList();
		DataMap rsMap = new DataMap();
		
		for(int i = 0 ; i < head.size() ; i ++){
			if(head.get(i).getMap("map").getString("ASNDKY").equals(headAsndky)){
				
				row = head.get(i).getMap("map");
				String docNum = wmsService.getDocSeq("112");
				docNumList.add(docNum);
				
				row.put("RECVKY", docNum);
				row.setModuleCommand("WmsInbound", "RECDH");
				row.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
				
				commonDao.update(row);
				
				for(int k = 0 ; k < selectList.size() ; k ++){
					itemRow = selectList.get(k).getMap("map");
					itemRow.put("RECVKY", docNum);
					itemRow.setModuleCommand("WmsInbound", "RECDI");
					
					itemCount += 10;
					String snum = String.valueOf(itemCount);
					String inum = String.valueOf("000000").substring(0,(6-snum.length()))+snum;
					
					itemRow.put("RECVIT", inum);
					
					count += commonDao.update(itemRow);
				}
				
			}else{
				row = head.get(i).getMap("map");
				String docNum = wmsService.getDocSeq("051");
				docNumList.add(docNum);
				
				row.put("RECVKY", docNum);
				row.setModuleCommand("WmsInbound", "RECDH");
				row.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
				
				commonDao.update(row);

				row.setModuleCommand("WmsInbound", "GR01Sub");
				
				List<DataMap> list = commonDao.getList(row); 
				
				for(int j = 0 ; j < list.size() ; j ++){
					itemRow = list.get(j);
					itemRow.put("RECVKY", docNum);
					itemRow.setModuleCommand("WmsInbound", "RECDI");
					
					itemCount += 10;
					String snum = String.valueOf(itemCount);
					String inum = String.valueOf("000000").substring(0,(6-snum.length()))+snum;
					
					itemRow.put("RECVIT", inum);
					commonDao.update(itemRow);
					
				}
			}
			
			StringBuilder sb = new StringBuilder();
			for(int k = 0 ; k < docNumList.size() ; k ++){
				if(k != 0){
					sb.append(",");
				}
				sb.append("'").append(docNumList.get(k)).append("'");
			}
			rsMap.put("RECVKY", sb.toString());
		}
		return rsMap;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	@Transactional
	public DataMap saveGr15(DataMap map) throws SQLException {
		List<DataMap> head = map.getList("head");
		List<DataMap> selectList = new ArrayList<DataMap>();
		if( map.get("list") != null && !map.get("list").equals("")){
			selectList = map.getList("list");
		}
		String headShpoky = map.get("headShpoky").toString();
		
		int count = 0;
		int itemCount = 0;
		
		DataMap row;
		DataMap itemRow;
		
		List docNumList = new ArrayList();
		DataMap rsMap = new DataMap();
		
		for(int i = 0 ; i < head.size() ; i ++){
			if(head.get(i).getMap("map").getString("SHPOKY").equals(headShpoky)){
				
				row = head.get(i).getMap("map");
				String docNum = wmsService.getDocSeq("166");
				docNumList.add(docNum);
				
				row.put("RECVKY", docNum);
				row.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
				row.setModuleCommand("WmsInbound", "GR15");
				
				commonDao.update(row);
				
				for(int k = 0 ; k < selectList.size() ; k ++){
					itemRow = selectList.get(k).getMap("map");
					itemRow.put("RECVKY", docNum);
					itemRow.setModuleCommand("WmsInbound", "GR15Sub");
					
					itemCount += 10;
					String snum = String.valueOf(itemCount);
					String inum = String.valueOf("000000").substring(0,(6-snum.length()))+snum;
					
					itemRow.put("RECVIT", inum);
					
					count += commonDao.update(itemRow);
				}

			}else{
				row = head.get(i).getMap("map");
				
				String docNum = wmsService.getDocSeq("051");
				docNumList.add(docNum);
				
				row.setModuleCommand("WmsInbound", "GR15");
				row.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
				row.put("RECVKY", docNum);
				
				commonDao.update(row);

				row.setModuleCommand("WmsInbound", "GR15Sub");
				
				List<DataMap> list = commonDao.getList(row); 
				
				for(int j = 0 ; j < list.size() ; j ++){
					itemRow = list.get(j);
					itemRow.put("RECVKY", docNum);
					itemRow.setModuleCommand("WmsInbound", "GR15Sub");
					
					itemCount += 10;
					String snum = String.valueOf(itemCount);
					String inum = String.valueOf("000000").substring(0,(6-snum.length()))+snum;
					
					itemRow.put("RECVIT", inum);
					commonDao.update(itemRow);
					
				}
				
			}
			
			StringBuilder sb = new StringBuilder();
			for(int k = 0 ; k < docNumList.size() ; k ++){
				if(k != 0){
					sb.append(",");
				}
				sb.append("'").append(docNumList.get(k)).append("'");
			}
			map.setModuleCommand("WmsInbound", "GR15R");
			map.put("RECVKY", sb.toString());
			rsMap.put("RECVKY", sb.toString());
			//return count;
		}
		return rsMap;
	}
	
	@Transactional
	public String saveDL01ValueCheck(DataMap map) throws SQLException {
		String result = "OK";
		try{
			List<DataMap> list = map.getList("list");
			DataMap head = map.getMap("head").getMap("map");
			
			DataMap row;
			String VALIDATION_SQL = "";
			
			String validationSql = "";
			String key = map.get("key").toString();
			
			if(map.containsKey("key")){
				validationSql = util.urlCreateValidationSql(map, key);
				map.put(CommonConfig.VALIDATION_SQL_KEY, validationSql);
				map.put("WAREKY", head.getString("WAREKY"));
				map.setModuleCommand("WmsOutbound", "SHPDH");
				
				List<DataMap> vList = commonDao.getValidation(map);
				log.debug(":::::::::::"+vList.size());
				if(vList.size() > 0){
					result = "OUT_M0140 VBELN";
				}
			}
		}catch(Exception e){
			log.debug("validataion error = "+e);
		}
		log.debug(":::::::::::::::::::::"+result);
		return result;
	}
	
	@Transactional
	public int saveDl01(DataMap map) throws SQLException {
		DataMap head = map.getMap("head").getMap("map");
		List<DataMap> list = map.getList("list");
		
		if(head.getString("SHPMTY").toString().equals("266")){
			head.put("PTRCVR", head.getString("DPTNKY"));
		}
		
		// ownrky 조회
		head.setModuleCommand("WmsOutbound", "OWNRKY");
		String ownrky = (String) commonDao.getObject(head);
			
		head.put("OWNRKY", ownrky);
		head.put("STATDO", "NEW");
		head.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
		head.setModuleCommand("WmsOutbound", "SHPDH");
		
		//merge 문
		commonDao.insert(head);
		
		int count = 0;
		DataMap row = new DataMap();
		int itemCount = 0;
		String snum;
		String inum;
		for(int i=0;i<list.size();i++){
			row = list.get(i).getMap("map");
			row.put("OWNRKY", ownrky);
			row.setModuleCommand("WmsOutbound", "SHPDI");
			row.put("PROGID", "DL01");
			row.put("WAREKY", head.get("WAREKY"));
			row.put("SHPOKY", head.get("SHPOKY"));
			row.put("STATIT", "NEW");
			
			itemCount += 10;
			snum = String.valueOf(itemCount);
			inum = String.valueOf("000000").substring(0,(6-snum.length()))+snum;
			row.put("SHPOIT", inum);
			
			row.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
			
			// merge 문
			commonDao.insert(row);
			
			if(!row.getString("SHPMTY").toString().equals("299")){
				row.setModuleCommand("WmsOutbound", "IF113N00101");
				commonDao.update(row);
			}
			count++;
		}
		
		if(head.getString("SHPMTY").toString().equals("299")){
			head.setModuleCommand("WmsOutbound", "IF113STKNUM");
			commonDao.update(head);
		}
		
		if(!head.getString("DRELIN").toString().equals("V")){
			head.put("DRELIN", "V");
			head.setModuleCommand("WmsOutbound", "SHPDH");
			commonDao.update(head);
			
			if(head.getString("SHPMTY").toString().equals("299")){
				head.setModuleCommand("WmsOutbound", "IF113PROC");
				DataMap procMap = commonDao.getMap(head);
			}
			
			/*head.setModuleCommand("WmsOutbound", "IF313PROC");
			DataMap procSubMap = commonDao.getMap(head);*/
		}
		return count;
	}
	
	public String itemValueCheck(DataMap map) throws SQLException {
		String result = "OK";
		List<DataMap> list = map.getList("list");
		DataMap head = map.getMap("head");
		
		DataMap row;
		String VALIDATION_SQL = "";
		
		String validationSql = "";
		String key = map.get("key").toString();
		if(map.containsKey("key")){
			validationSql = util.itemCreateValidationSql(map, key);
			map.put(CommonConfig.VALIDATION_SQL_KEY, validationSql);
			map.put("WAREKY", head.getString("WAREKY"));
			map.setModuleCommand("WmsOutbound", "SHPDH");
		
			List<DataMap> vList = commonDao.getValidation(map);
			log.debug("size:::::::::::::"+vList.size());
			if(vList.size() > 0){
				result = "OUT_M0140 VBELN";
			}
		}
		log.debug("result:::::::::::::"+result);
		return result;
	}
	
	@Transactional
	public int saveDL01AllChkeck(DataMap map) throws SQLException, Exception {
		List<DataMap> head = map.getList("head");
		
		int count = 0;
		DataMap row = new DataMap();
		DataMap itemRow;
		DataMap validationMap = new DataMap();
		String validationResult = "";
		int validationCount = 0;
		for(int i=0;i<head.size();i++){
			row = head.get(i).getMap("map");
			
			// ownrky 조회
			row.setModuleCommand("WmsOutbound", "OWNRKY");
			String ownrky = (String) commonDao.getObject(row);
			
			if(row.getString("SHPMTY").equals("266")){
				row.put("PTRCVR", row.getString("DPTNKY"));
			}
			
			row.put("OWNRKY", ownrky);
			row.put("STATDO", "NEW");
			row.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
			row.setModuleCommand("WmsOutbound", "SHPDH");

			//merge 문
			commonDao.insert(row);
			count++;
			
			row.setModuleCommand("WmsOutbound", "DL01");
			List<DataMap> itemList =commonDao.getList(row);
			
			int itemCount = 0;
			String snum;
			String inum;
			// item table validation
			for(int j = 0; j < itemList.size(); j++){
				itemRow = new DataMap(itemList.get(j));
				validationMap.put("head", row);
				validationMap.put("list", itemList);
				validationMap.put("key", "SMANDT,SVBELN,SPOSNR,SKUKEY,QTSHPO");
				validationResult = itemValueCheck(validationMap);
				
				if(!validationResult.equals("OK")){
					validationCount++;
					break;
				}else{
					itemRow.put("OWNRKY", ownrky);
					itemRow.setModuleCommand("WmsOutbound", "SHPDI");
					itemRow.put("PROGID", row.getString("PROGID"));
					itemRow.put("WAREKY", row.getString("WAREKY"));
					itemRow.put("SHPOKY", row.getString("SHPOKY"));
					itemRow.put("STATIT", "NEW");
					
					itemCount += 10;
					snum = String.valueOf(itemCount);
					inum = String.valueOf("000000").substring(0,(6-snum.length()))+snum;
					itemRow.put("SHPOIT", inum);
					
					itemRow.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
					
					try{
						
						itemRow.put("QTSORG", itemRow.getString("QTSORG"));
						itemRow.put("QTSHPO", itemRow.getString("QTSHPO"));
						itemRow.put("QTYREF", itemRow.getString("QTYREF"));
						itemRow.put("QTUALO", itemRow.getString("QTUALO"));
						itemRow.put("QTAPPO", itemRow.getString("QTAPPO"));
						itemRow.put("QTALOC", itemRow.getString("QTALOC"));
						itemRow.put("QTJCMP", itemRow.getString("QTJCMP"));
						itemRow.put("QTSHPD", itemRow.getString("QTSHPD"));
						itemRow.put("QTSHPC", itemRow.getString("QTSHPC"));
						itemRow.put("QTYUOM", itemRow.getString("QTYUOM"));
						itemRow.put("QTPUOM", itemRow.getString("QTPUOM"));
						itemRow.put("QTDUOM", itemRow.getString("QTDUOM"));
						itemRow.put("GRSWGT", itemRow.getString("GRSWGT"));
						itemRow.put("NETWGT", itemRow.getString("NETWGT"));
						itemRow.put("LENGTH", itemRow.getString("LENGTH"));
						itemRow.put("WIDTHW", itemRow.getString("WIDTHW"));
						itemRow.put("HEIGHT", itemRow.getString("HEIGHT"));
						itemRow.put("CUBICM", itemRow.getString("CUBICM"));
						itemRow.put("CAPACT", itemRow.getString("CAPACT"));
						itemRow.put("LOTA16", itemRow.getString("LOTA16"));
						itemRow.put("LOTA17", itemRow.getString("LOTA17"));
						itemRow.put("LOTA18", itemRow.getString("LOTA18"));
						itemRow.put("LOTA19", itemRow.getString("LOTA19"));
						itemRow.put("LOTA20", itemRow.getString("LOTA20"));
						itemRow.put("AWMSNO", itemRow.getString("AWMSNO"));
						itemRow.put("WGTUNT", itemRow.getString("WGTUNT"));
						
						commonDao.insert(itemRow);
					}catch(Exception e){
						log.debug("error::::::::::::::::::"+e);
					}
					
					log.debug("SHPMTY:::::::::::::::::::::"+row.getString("SHPMTY"));
					if(!row.getString("SHPMTY").toString().equals("299")){
						itemRow.setModuleCommand("WmsOutbound", "IF113N00101");
						commonDao.update(itemRow);
					}
				}
			}
			
			// 헤더 정보 저장.
			if(validationResult.equals("OK")){
				if(row.getString("SHPMTY").toString().equals("299")){
					row.setModuleCommand("WmsOutbound", "IF113STKNUM");
					commonDao.update(row);
				}
	
				if(!row.getString("DRELIN").toString().equals("V")){
					row.put("DRELIN", "V");
					row.setModuleCommand("WmsOutbound", "SHPDH");
					commonDao.update(row);
				}
			}
		}
		
		if(validationCount > 0){
			count = 0;
			throw new Exception();
		}
		
		return count;
	}
	
	@Transactional(rollbackFor=Exception.class)
	public int DL01IndexSelectCheckSave(DataMap map) throws SQLException, Exception {
		List<DataMap> head = map.getList("head");
		DataMap focusHead = map.getMap("focusHead").getMap("map");
		List<DataMap> list = map.getList("list");
		String rowHeadIdx = map.get("rowHeadIdx").toString();
		String selRowidx = map.get("arrSelRowIdx").toString();
		
		
		/**
		 * 선택된 헤드 정보와 아이탬 정보 저장
		 */
		if(focusHead.getString("SHPMTY").toString().equals("266")){
			focusHead.put("PTRCVR", focusHead.getString("DPTNKY"));
		}
		
		// ownrky 조회
		focusHead.setModuleCommand("WmsOutbound", "OWNRKY");
		String ownrky = (String) commonDao.getObject(focusHead);
		
		focusHead.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
		focusHead.put("OWNRKY", ownrky);
		focusHead.put("STATDO", "NEW");
		focusHead.setModuleCommand("WmsOutbound", "SHPDH");
		
		//merge 문
		commonDao.insert(focusHead);
		
		int count = 0;
		DataMap row = new DataMap();
		int itemCount = 0;
		String snum;
		String inum;
		for(int i=0;i<list.size();i++){
			row = list.get(i).getMap("map");
			row.put("OWNRKY", ownrky);
			row.setModuleCommand("WmsOutbound", "SHPDI");
			row.put("PROGID", "DL01");
			row.put("WAREKY", focusHead.get("WAREKY"));
			row.put("SHPOKY", focusHead.get("SHPOKY"));
			row.put("STATIT", "NEW");
			
			itemCount += 10;
			snum = String.valueOf(itemCount);
			inum = String.valueOf("000000").substring(0,(6-snum.length()))+snum;
			row.put("SHPOIT", inum);
			row.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
			
			// merge 문
			commonDao.insert(row);
			
			if(!row.getString("SHPMTY").toString().equals("299")){
				row.setModuleCommand("WmsOutbound", "IF113N00101");
				commonDao.update(row);
			}
			count++;
		}
		
		if(focusHead.getString("SHPMTY").toString().equals("299")){
			focusHead.setModuleCommand("WmsOutbound", "IF113STKNUM");
			commonDao.update(focusHead);
		}
		
		if(!focusHead.getString("DRELIN").toString().equals("V")){
			focusHead.put("DRELIN", "V");
			focusHead.setModuleCommand("WmsOutbound", "SHPDH");
			commonDao.update(focusHead);
		}
		
		/**
		 * 체크된 헤드 정보 저장.(아이탬 정보 일괄 처리)
		 */
		String[] arrIdx = selRowidx.split(",");
		DataMap itemRow;
		DataMap validationMap = new DataMap();
		String validationResult = "";
		int validationCount = 0;
		
		for(int i=0;i<arrIdx.length;i++){
			// 체크된 row의 index와 선택된 row index가 동일함.
			if(!arrIdx[i].equals(rowHeadIdx)){
				row = head.get(i).getMap("map");
				if(row.getString("SHPMTY").equals("266")){
					row.put("PTRCVR", row.getString("DPTNKY"));
				}
				
				try{
					row.put("OWNRKY", ownrky);
					row.put("STATDO", "NEW");
					row.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
					row.setModuleCommand("WmsOutbound", "SHPDH");
		
					//merge 문
					commonDao.insert(row);
				}catch(Exception e){
					log.debug("error:::::::::::::::::::::"+e);
				}
				count++;
				row.setModuleCommand("WmsOutbound", "DL01");
				List<DataMap> itemList =commonDao.getList(row);
				
				itemCount = 0;
				// item table validation
				for(int j = 0; j < itemList.size(); j++){
					itemRow = new DataMap(itemList.get(j));
					validationMap.put("head", row);
					validationMap.put("list", itemList);
					validationMap.put("key", "SMANDT,SVBELN,SPOSNR,SKUKEY,QTSHPO");
					validationResult = itemValueCheck(validationMap);
					
					if(!validationResult.equals("OK")){
						validationCount++;
						break;
					}else{
						itemRow.put("OWNRKY", ownrky);
						itemRow.setModuleCommand("WmsOutbound", "SHPDI");
						itemRow.put("PROGID", row.getString("PROGID"));
						itemRow.put("WAREKY", row.getString("WAREKY"));
						itemRow.put("SHPOKY", row.getString("SHPOKY"));
						itemRow.put("STATIT", "NEW");
						
						itemCount += 10;
						snum = String.valueOf(itemCount);
						inum = String.valueOf("000000").substring(0,(6-snum.length()))+snum;
						itemRow.put("SHPOIT", inum);
						
						itemRow.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
						
						// merge 문
						try{
							
							itemRow.put("QTSORG", itemRow.getString("QTSORG"));
							itemRow.put("QTSHPO", itemRow.getString("QTSHPO"));
							itemRow.put("QTYREF", itemRow.getString("QTYREF"));
							itemRow.put("QTUALO", itemRow.getString("QTUALO"));
							itemRow.put("QTAPPO", itemRow.getString("QTAPPO"));
							itemRow.put("QTALOC", itemRow.getString("QTALOC"));
							itemRow.put("QTJCMP", itemRow.getString("QTJCMP"));
							itemRow.put("QTSHPD", itemRow.getString("QTSHPD"));
							itemRow.put("QTSHPC", itemRow.getString("QTSHPC"));
							itemRow.put("QTYUOM", itemRow.getString("QTYUOM"));
							itemRow.put("QTPUOM", itemRow.getString("QTPUOM"));
							itemRow.put("QTDUOM", itemRow.getString("QTDUOM"));
							itemRow.put("GRSWGT", itemRow.getString("GRSWGT"));
							itemRow.put("NETWGT", itemRow.getString("NETWGT"));
							itemRow.put("LENGTH", itemRow.getString("LENGTH"));
							itemRow.put("WIDTHW", itemRow.getString("WIDTHW"));
							itemRow.put("HEIGHT", itemRow.getString("HEIGHT"));
							itemRow.put("CUBICM", itemRow.getString("CUBICM"));
							itemRow.put("CAPACT", itemRow.getString("CAPACT"));
							itemRow.put("LOTA16", itemRow.getString("LOTA16"));
							itemRow.put("LOTA17", itemRow.getString("LOTA17"));
							itemRow.put("LOTA18", itemRow.getString("LOTA18"));
							itemRow.put("LOTA19", itemRow.getString("LOTA19"));
							itemRow.put("LOTA20", itemRow.getString("LOTA20"));
							itemRow.put("AWMSNO", itemRow.getString("AWMSNO"));
							itemRow.put("WGTUNT", itemRow.getString("WGTUNT"));
							
							commonDao.insert(itemRow);
						}catch(Exception e){
							log.debug("error::::::::::::::::::"+e);
						}
						
						log.debug("SHPMTY:::::::::::::::::::::"+row.getString("SHPMTY"));
						if(!row.getString("SHPMTY").toString().equals("299")){
							itemRow.setModuleCommand("WmsOutbound", "IF113N00101");
							commonDao.update(itemRow);
						}
					}
				}
				count++;
				// 헤더 정보 저장.
				if(validationResult.equals("OK")){
					if(row.getString("SHPMTY").toString().equals("299")){
						row.setModuleCommand("WmsOutbound", "IF113STKNUM");
						commonDao.update(row);
					}
		
					if(!row.getString("DRELIN").toString().equals("V")){
						row.put("DRELIN", "V");
						row.setModuleCommand("WmsOutbound", "SHPDH");
						commonDao.update(row);
					}
				}
			}
		}
		
		if(validationCount > 0){
			count = 0;
			throw new Exception();
		}
		
		return count;
	}
	
	@Transactional
	public int assignmentDl01(DataMap map) throws SQLException {
		DataMap head = map.getMap("head").getMap("map");
		List<DataMap> list = map.getList("list");
		
		if(head.getString("SHPMTY").toString().equals("266")){
			head.put("PTRCVR", head.getString("DPTNKY"));
		}
		
		// ownrky 조회
		head.setModuleCommand("WmsOutbound", "OWNRKY");
		String ownrky = (String) commonDao.getObject(head);
			
		head.put("OWNRKY", ownrky);
		head.put("STATDO", "NEW");
		head.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
		head.setModuleCommand("WmsOutbound", "SHPDH");
		
		//merge 문
		commonDao.insert(head);
		
		int count = 0;
		DataMap row = new DataMap();
		int itemCount = 0;
		String snum;
		String inum;
		for(int i=0;i<list.size();i++){
			row = list.get(i).getMap("map");
			row.put("OWNRKY", ownrky);
			row.setModuleCommand("WmsOutbound", "SHPDI");
			row.put("PROGID", "DL01");
			row.put("WAREKY", head.get("WAREKY"));
			row.put("SHPOKY", head.get("SHPOKY"));
			row.put("STATIT", "NEW");
			
			itemCount += 10;
			snum = String.valueOf(itemCount);
			inum = String.valueOf("000000").substring(0,(6-snum.length()))+snum;
			row.put("SHPOIT", inum);
			row.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
			
			try{
				commonDao.insert(row);
			}catch(Exception e){
				log.debug("error :::" + e);
			}
			if(!row.getString("SHPMTY").toString().equals("299")){
				row.setModuleCommand("WmsOutbound", "IF113N00101");
				commonDao.update(row);
			}
			count++;
		}
		
		if(head.getString("SHPMTY").toString().equals("299")){
			head.setModuleCommand("WmsOutbound", "IF113STKNUM");
			commonDao.update(head);
		}
		
		if(!head.getString("DRELIN").toString().equals("V")){
			head.put("DRELIN", "V");
			head.setModuleCommand("WmsOutbound", "SHPDH");
			commonDao.update(head);
			
			if(head.getString("SHPMTY").toString().equals("299")){
				head.setModuleCommand("WmsOutbound", "IF113PROC");
				DataMap procMap = commonDao.getMap(head);
			}
			
			/*head.setModuleCommand("WmsOutbound", "IF313PROC");
			DataMap procSubMap = commonDao.getMap(head);*/
		}
		
		try{
			head.setModuleCommand("WmsOutbound", "BATCHALLOCATION");
			DataMap procSubMap = commonDao.getMap(head);
		}catch(Exception e){
			log.debug("proc error :::"+e);
		}
		
		return count;
	}
	
	@Transactional
	public int assignmentAllDl01(DataMap map) throws SQLException, Exception {
		List<DataMap> head = map.getList("head");
		
		int count = 0;
		DataMap row = new DataMap();
		DataMap itemRow;
		DataMap validationMap = new DataMap();
		String validationResult = "";
		int validationCount = 0;
		DataMap procMap;
		for(int i=0;i<head.size();i++){
			row = head.get(i).getMap("map");
			
			// ownrky 조회
			row.setModuleCommand("WmsOutbound", "OWNRKY");
			String ownrky = (String) commonDao.getObject(row);
			
			if(row.getString("SHPMTY").equals("266")){
				row.put("PTRCVR", row.getString("DPTNKY"));
			}
			
			row.put("OWNRKY", ownrky);
			row.put("STATDO", "NEW");
			row.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
			row.setModuleCommand("WmsOutbound", "SHPDH");

			commonDao.insert(row);
			count++;
			
			row.setModuleCommand("WmsOutbound", "DL01");
			List<DataMap> itemList =commonDao.getList(row);
			
			int itemCount = 0;
			String snum;
			String inum;
			// item table validation
			for(int j = 0; j < itemList.size(); j++){
				itemRow = new DataMap(itemList.get(j));
				validationMap.put("head", row);
				validationMap.put("list", itemList);
				validationMap.put("key", "SMANDT,SVBELN,SPOSNR,SKUKEY,QTSHPO");
				validationResult = itemValueCheck(validationMap);
				
				if(!validationResult.equals("OK")){
					validationCount++;
					break;
				}else{
					itemRow.put("OWNRKY", ownrky);
					itemRow.setModuleCommand("WmsOutbound", "SHPDI");
					itemRow.put("PROGID", row.getString("PROGID"));
					itemRow.put("WAREKY", row.getString("WAREKY"));
					itemRow.put("SHPOKY", row.getString("SHPOKY"));
					itemRow.put("STATIT", "NEW");
					
					itemCount += 10;
					snum = String.valueOf(itemCount);
					inum = String.valueOf("000000").substring(0,(6-snum.length()))+snum;
					itemRow.put("SHPOIT", inum);
					itemRow.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
					
					try{
						itemRow.put("QTSORG", itemRow.getString("QTSORG"));
						itemRow.put("QTSHPO", itemRow.getString("QTSHPO"));
						itemRow.put("QTYREF", itemRow.getString("QTYREF"));
						itemRow.put("QTUALO", itemRow.getString("QTUALO"));
						itemRow.put("QTAPPO", itemRow.getString("QTAPPO"));
						itemRow.put("QTALOC", itemRow.getString("QTALOC"));
						itemRow.put("QTJCMP", itemRow.getString("QTJCMP"));
						itemRow.put("QTSHPD", itemRow.getString("QTSHPD"));
						itemRow.put("QTSHPC", itemRow.getString("QTSHPC"));
						itemRow.put("QTYUOM", itemRow.getString("QTYUOM"));
						itemRow.put("QTPUOM", itemRow.getString("QTPUOM"));
						itemRow.put("QTDUOM", itemRow.getString("QTDUOM"));
						itemRow.put("GRSWGT", itemRow.getString("GRSWGT"));
						itemRow.put("NETWGT", itemRow.getString("NETWGT"));
						itemRow.put("LENGTH", itemRow.getString("LENGTH"));
						itemRow.put("WIDTHW", itemRow.getString("WIDTHW"));
						itemRow.put("HEIGHT", itemRow.getString("HEIGHT"));
						itemRow.put("CUBICM", itemRow.getString("CUBICM"));
						itemRow.put("CAPACT", itemRow.getString("CAPACT"));
						itemRow.put("LOTA16", itemRow.getString("LOTA16"));
						itemRow.put("LOTA17", itemRow.getString("LOTA17"));
						itemRow.put("LOTA18", itemRow.getString("LOTA18"));
						itemRow.put("LOTA19", itemRow.getString("LOTA19"));
						itemRow.put("LOTA20", itemRow.getString("LOTA20"));
						itemRow.put("AWMSNO", itemRow.getString("AWMSNO"));
						itemRow.put("WGTUNT", itemRow.getString("WGTUNT"));
						
						commonDao.insert(itemRow);
					}catch(Exception e){
						log.debug("error::::::::::::::::::"+e);
					}
					
					if(!row.getString("SHPMTY").toString().equals("299")){
						itemRow.setModuleCommand("WmsOutbound", "IF113N00101");
						commonDao.update(itemRow);
					}
				}
			}
			
			// 헤더 정보 저장.
			if(validationResult.equals("OK")){
				if(row.getString("SHPMTY").toString().equals("299")){
					row.setModuleCommand("WmsOutbound", "IF113STKNUM");
					commonDao.update(row);
				}
	
				if(!row.getString("DRELIN").toString().equals("V")){
					row.put("DRELIN", "V");
					row.setModuleCommand("WmsOutbound", "SHPDH");
					commonDao.update(row);
				}
				
				row.setModuleCommand("WmsOutbound", "BATCHALLOCATION");
				procMap = commonDao.getMap(row);
			}
		}
		
		if(validationCount > 0){
			count = 0;
			throw new Exception();
		}
		
		return count;
	}
	
	@Transactional
	public int DL01IndexSelectCheckAssignment(DataMap map) throws SQLException, Exception {
		List<DataMap> head = map.getList("head");
		DataMap focusHead = map.getMap("focusHead").getMap("map");
		List<DataMap> list = map.getList("list");
		String rowHeadIdx = map.get("rowHeadIdx").toString();
		String selRowidx = map.get("arrSelRowIdx").toString();
		
		/**
		 * 선택된 헤드 정보와 아이탬 정보 저장
		 */
		if(focusHead.getString("SHPMTY").toString().equals("266")){
			focusHead.put("PTRCVR", focusHead.getString("DPTNKY"));
		}
		
		// ownrky 조회
		focusHead.setModuleCommand("WmsOutbound", "OWNRKY");
		String ownrky = (String) commonDao.getObject(focusHead);
			
		focusHead.put("OWNRKY", ownrky);
		focusHead.put("STATDO", "NEW");
		focusHead.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
		focusHead.setModuleCommand("WmsOutbound", "SHPDH");
		
		commonDao.insert(focusHead);
		
		int count = 0;
		DataMap row = new DataMap();
		int itemCount = 0;
		String snum;
		String inum;
		for(int i=0;i<list.size();i++){
			row = list.get(i).getMap("map");
			row.put("OWNRKY", ownrky);
			row.setModuleCommand("WmsOutbound", "SHPDI");
			row.put("PROGID", "DL01");
			row.put("WAREKY", focusHead.get("WAREKY"));
			row.put("SHPOKY", focusHead.get("SHPOKY"));
			row.put("STATIT", "NEW");
			
			itemCount += 10;
			snum = String.valueOf(itemCount);
			inum = String.valueOf("000000").substring(0,(6-snum.length()))+snum;
			row.put("SHPOIT", inum);
			row.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
			
			commonDao.insert(row);
			
			if(!row.getString("SHPMTY").toString().equals("299")){
				row.setModuleCommand("WmsOutbound", "IF113N00101");
				commonDao.update(row);
			}
			count++;
		}
		
		if(focusHead.getString("SHPMTY").toString().equals("299")){
			focusHead.setModuleCommand("WmsOutbound", "IF113STKNUM");
			commonDao.update(focusHead);
		}
		
		if(!focusHead.getString("DRELIN").toString().equals("V")){
			focusHead.put("DRELIN", "V");
			focusHead.setModuleCommand("WmsOutbound", "SHPDH");
			commonDao.update(focusHead);
		}
		
		row.setModuleCommand("WmsOutbound", "BATCHALLOCATION");
		DataMap procSubMap = commonDao.getMap(row);
		
		/**
		 * 체크된 헤드 정보 저장.(아이탬 정보 일괄 처리)
		 */
		String[] arrIdx = selRowidx.split(",");
		DataMap itemRow;
		DataMap validationMap = new DataMap();
		String validationResult = "";
		int validationCount = 0;
		
		for(int i=0;i<arrIdx.length;i++){
			// 체크된 row의 index와 선택된 row index가 동일함.
			if(!arrIdx[i].equals(rowHeadIdx)){
				row = head.get(i).getMap("map");
				if(row.getString("SHPMTY").equals("266")){
					row.put("PTRCVR", row.getString("DPTNKY"));
				}
				
				try{
					row.put("OWNRKY", ownrky);
					row.put("STATDO", "NEW");
					row.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
					row.setModuleCommand("WmsOutbound", "SHPDH");
		
					commonDao.insert(row);
				}catch(Exception e){
					log.debug("error:::::::::::::::::::::"+e);
				}
				count++;
	
				row.setModuleCommand("WmsOutbound", "DL01");
				List<DataMap> itemList =commonDao.getList(row);
	
				itemCount = 0;
				// item table validation
				for(int j = 0; j < itemList.size(); j++){
					itemRow = new DataMap(itemList.get(j));
					validationMap.put("head", row);
					validationMap.put("list", itemList);
					validationMap.put("key", "SMANDT,SVBELN,SPOSNR,SKUKEY,QTSHPO");
					validationResult = itemValueCheck(validationMap);
					
					if(!validationResult.equals("OK")){
						validationCount++;
						break;
					}else{
						itemRow.put("OWNRKY", ownrky);
						itemRow.setModuleCommand("WmsOutbound", "SHPDI");
						itemRow.put("PROGID", row.getString("PROGID"));
						itemRow.put("WAREKY", row.getString("WAREKY"));
						itemRow.put("SHPOKY", row.getString("SHPOKY"));
						itemRow.put("STATIT", "NEW");
						
						itemCount += 10;
						snum = String.valueOf(itemCount);
						inum = String.valueOf("000000").substring(0,(6-snum.length()))+snum;
						itemRow.put("SHPOIT", inum);
						itemRow.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
		
						try{
							itemRow.put("QTSORG", itemRow.getString("QTSORG"));
							itemRow.put("QTSHPO", itemRow.getString("QTSHPO"));
							itemRow.put("QTYREF", itemRow.getString("QTYREF"));
							itemRow.put("QTUALO", itemRow.getString("QTUALO"));
							itemRow.put("QTAPPO", itemRow.getString("QTAPPO"));
							itemRow.put("QTALOC", itemRow.getString("QTALOC"));
							itemRow.put("QTJCMP", itemRow.getString("QTJCMP"));
							itemRow.put("QTSHPD", itemRow.getString("QTSHPD"));
							itemRow.put("QTSHPC", itemRow.getString("QTSHPC"));
							itemRow.put("QTYUOM", itemRow.getString("QTYUOM"));
							itemRow.put("QTPUOM", itemRow.getString("QTPUOM"));
							itemRow.put("QTDUOM", itemRow.getString("QTDUOM"));
							itemRow.put("GRSWGT", itemRow.getString("GRSWGT"));
							itemRow.put("NETWGT", itemRow.getString("NETWGT"));
							itemRow.put("LENGTH", itemRow.getString("LENGTH"));
							itemRow.put("WIDTHW", itemRow.getString("WIDTHW"));
							itemRow.put("HEIGHT", itemRow.getString("HEIGHT"));
							itemRow.put("CUBICM", itemRow.getString("CUBICM"));
							itemRow.put("CAPACT", itemRow.getString("CAPACT"));
							itemRow.put("LOTA16", itemRow.getString("LOTA16"));
							itemRow.put("LOTA17", itemRow.getString("LOTA17"));
							itemRow.put("LOTA18", itemRow.getString("LOTA18"));
							itemRow.put("LOTA19", itemRow.getString("LOTA19"));
							itemRow.put("LOTA20", itemRow.getString("LOTA20"));
							itemRow.put("AWMSNO", itemRow.getString("AWMSNO"));
							itemRow.put("WGTUNT", itemRow.getString("WGTUNT"));
						
							commonDao.insert(itemRow);
						}catch(Exception e){
							log.debug("error::::::::::::::::::"+e);
						}
						
						if(!row.getString("SHPMTY").toString().equals("299")){
							itemRow.setModuleCommand("WmsOutbound", "IF113N00101");
							commonDao.update(itemRow);
						}
					}
				}
				count++;
				// 헤더 정보 저장.
				if(validationResult.equals("OK")){
					if(row.getString("SHPMTY").toString().equals("299")){
						row.setModuleCommand("WmsOutbound", "IF113STKNUM");
						commonDao.update(row);
					}
		
					if(!row.getString("DRELIN").toString().equals("V")){
						row.put("DRELIN", "V");
						row.setModuleCommand("WmsOutbound", "SHPDH");
						commonDao.update(row);
					}
					
					row.setModuleCommand("WmsOutbound", "BATCHALLOCATION");
					procSubMap = commonDao.getMap(row);
				}
			}
		}
		
		if(validationCount > 0){
			count = 0;
			throw new Exception();
		}
		
		return count;
	}
	
	@Transactional
	public int DL01OrderDelete(DataMap map) throws SQLException {
		List<DataMap> head = map.getList("head");
		
		int count = 0;
		DataMap row;
		for(int i=0;i<head.size();i++){
			row = head.get(i).getMap("map");
			row.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
			row.setModuleCommand("WmsOutbound", "BATCHALLOCATION");
			DataMap procSubMap = commonDao.getMap(row);			
			count++;
		}
		
		return count;
	}
	
	@Transactional
	public List DL01Barcode(DataMap map) throws SQLException {
		Map head = map.getMap("head").getMap("map");
		List<DataMap> list = map.getList("list");
		List dataList = new ArrayList();
		
		map.setModuleCommand("WmsOutbound", "BARCODREFDKY");
		DataMap row;
		
		int refdky = -1;
		for(int i=0;i<list.size();i++){
			row = list.get(i).getMap("map");
			
			if(row.getInt("QTSHPO") > 0){
				row.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
				
				int count = row.getInt("QTSHPO");
				
				if(count > 0){
					if(refdky == -1){
						refdky = (Integer)commonDao.getObject(map);
					}
					row.setModuleCommand("WmsOutbound", "BARCOD");
					row.put("REFDKY",refdky);
					row.put("WAREKY",head.get("WAREKY"));
					
					if(row.getString("BATMNG").equals("V")){
						for(int j=0;j<count;j++){
							row.put("QTSHPO", "1");
							commonDao.insert(row);
						}
					}else{
						commonDao.insert(row);
					}
					
					row.setModuleCommand("WmsOutbound", "BARCD");
					
					List tmpList = commonDao.getList(row);
					
					dataList.addAll(tmpList);
				}
			}
		}
		
		return dataList;
	}
	
	@Transactional
	public int DL04Assignment(DataMap map) throws SQLException {
		List<DataMap> head = map.getList("head");
		List<DataMap> list = map.getList("list");
		
		int count = 0;
		DataMap row;
		DataMap procMap;
		for(int i=0;i<head.size();i++){
			row = head.get(i).getMap("map");
			row.setModuleCommand("WmsOutbound", "BATCHALLOCATION");
			row.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
			
			procMap = commonDao.getMap(row);
			
			count++;
		}
		
		return count;
	}
	
	@Transactional
	public int DL04Delete(DataMap map) throws SQLException {
		List<DataMap> head = map.getList("head");
		
		int count = 0;
		DataMap row = new DataMap();
		for(int i=0;i<head.size();i++){
			row = head.get(i).getMap("map");
			row.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
			row.setModuleCommand("WmsOutbound", "ALLOCATIONCANCLE");
			commonDao.update(row);
			
			row.setModuleCommand("WmsOutbound", "ALLOCATIONCANCLE");
			commonDao.update(row);
			/*
			row.setModuleCommand("WmsOutbound", "IF313PROC");
			DataMap procSubMap = commonDao.getMap(row);
			
			if(row.getString("SHPMTY").equals("299")){
				row.setModuleCommand("WmsOutbound", "PDELSHPREF");
				DataMap delShpMap = commonDao.getMap(row);
			}
			*/
			row.setModuleCommand("WmsOutbound", "REMOVETASKKY");
			String taskky = (String) commonDao.getObject(row);
			if(taskky != null && !taskky.equals("")){
				row.setModuleCommand("WmsOutbound", "REMOVETASDI");
				row.put("TASKKY", taskky);
				commonDao.delete(row);
				
				row.setModuleCommand("WmsOutbound", "REMOVETASDH");
				commonDao.delete(row);
			}
			
			if(row.getString("SHPMTY").equals("299")){
				
			}else{
				row.setModuleCommand("WmsOutbound", "TKNUMQNTSUB");
				commonDao.update(row);
			}
			
			row.setModuleCommand("WmsOutbound", "SHPDI");
			commonDao.delete(row);
			
			row.setModuleCommand("WmsOutbound", "SHPDH");
			commonDao.delete(row);
			
			count++;
		}
		
		return count;
	}
	
	@Transactional
	public int DL04orderDelete(DataMap map) throws SQLException {
		List<DataMap> head = map.getList("head");
		
		int count = 0;
		DataMap row = new DataMap();
		for(int i=0;i<head.size();i++){
			row = head.get(i).getMap("map");
			row.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));

			row.setModuleCommand("WmsOutbound", "REMOVETASKKY");
			String taskky = (String) commonDao.getObject(row);
			if(taskky != null && !taskky.equals("")){
				row.setModuleCommand("WmsOutbound", "REMOVETASDI");
				row.put("TASKKY", taskky);
				commonDao.delete(row);
				
				row.setModuleCommand("WmsOutbound", "REMOVETASDH");
				commonDao.delete(row);
			}
			
			count++;
		}
		
		return count;
	}
	
	@Transactional
	public int DL04POPSave(DataMap map) throws SQLException, Exception {
		List<DataMap> list = map.getList("list");
		
		String TASOTY = "210";
		String DOCCAT = "300";
		String STATDO = "NEW";
		
		SimpleDateFormat fmDate = new SimpleDateFormat("yyyyMMdd", Locale.KOREA);
		String date = fmDate.format(new Date());
		SimpleDateFormat fmTime = new SimpleDateFormat("HHmmss", Locale.KOREA);
		String time = fmTime.format(new Date());
		
		String ownrky = map.getString("OWNRKY");
		String wareky = map.getString("WAREKY");
		String areaky = map.getString("AREAKY");
		String skukey = map.getString("SKUKEY");
		String shpoky = map.getString("SHPOKY");
		String shpoit = map.getString("SHPOIT");
		
		
		int count = 1;
		// 1. Shipment Order Header, Item 및 ERP사용자 정보 조회
		map.setModuleCommand("WmsOutbound", "SEARCHSHPDH");
		DataMap shpdhMap = commonDao.getMap(map);
		
		map.setModuleCommand("WmsOutbound", "SEARCHSHPDI");
		DataMap shpdiMap = commonDao.getMap(map);	
		
		// 2.Shipment Order Item No 기준으로 NEW 상태의 기존 Task Order 모두 삭제
		map.setModuleCommand("WmsOutbound", "DL04POPREMOVE");
		commonDao.delete(map);
		
		// 3. Task Order Header 신규 생성
		map.setModuleCommand("WmsOutbound", "GEN_TASKKY");
		map.put("TASOTY", TASOTY);
		DataMap taskkyMap = commonDao.getMap(map);
		
		String taskky = (String)taskkyMap.get("TASKKY");
		int taskit = 0;
		
		map.put("TASKKY", taskky);
		map.put("WAREKY", shpdhMap.get("WAREKY"));
		map.put("TASOTY", TASOTY);
		map.put("DOCDAT", date);
		map.put("DOCCAT", DOCCAT);
		map.put("DRELIN", " ");
		map.put("STATDO", STATDO);
		map.put("QTTAOR", "0");
		map.put("QTCOMP", "0");
		map.put("TSPKEY", " ");
		map.put("DOORKY", " ");
		map.put("WARETG", " ");
		map.put("PTNRKY", " ");
		map.put("PTNRTY", " ");
		map.put("PTNRNM", " ");
		map.put("USRID1", " ");
		map.put("UNAME1", " ");
		map.put("DEPTID1", " ");
		map.put("DNAME1", " ");
		map.put("USRID2", " ");
		map.put("UNAME2", " ");
		map.put("DEPTID2", " ");
		map.put("DNAME2", " ");
		map.put("USRID3", " ");
		map.put("UNAME3", " ");
		map.put("DEPTID3", " ");
		map.put("DNAME3", " ");
		map.put("USRID4", " ");
		map.put("UNAME4", " ");
		map.put("DEPTID4", " ");
		map.put("DNAME4", " ");
		map.put("DOCTXT", " ");
		map.put("CREDAT", date);
		map.put("CRETIM", time);
		map.put("CREUSR", CommonConfig.SES_USER_ID_KEY);
		map.put("LMODAT", date);
		map.put("LMOTIM", time);
		map.put("LMOUSR", CommonConfig.SES_USER_ID_KEY);
		map.put("INDBZL", " ");
		map.put("INDARC", " ");
		map.put("UPDCHK", "0");
		map.put("KEEPTS", " ");
		
		map.setModuleCommand("WmsTask", "TASDH");
		commonDao.insert(map);
		
		// 5. 재고 SELECT하여 Task Order Item/Reference 생성
		DataMap rowData = null;
		BigDecimal qty, qttaor, qtsiwh = null;
		for(DataMap row : list){
			rowData = (DataMap)row.get("map");
			
			qty = new BigDecimal((String)rowData.get("QTSALO"));
			if(qty.compareTo(BigDecimal.ZERO) <= 0)
				continue;
			
			// 재고 셀렉트
			map.setModuleCommand("WmsOutbound", "MANUALALLOCATE_AVAILABLE_STOCK");
			map.put("OWNRKY", rowData.get("OWNRKY"));
			map.put("WAREKY", rowData.get("WAREKY"));
			map.put("AREAKY", rowData.get("AREAKY"));
			map.put("LOCAKY", rowData.get("LOCAKY"));
			map.put("SKUKEY", rowData.get("SKUKEY"));
			map.put("TRNUID", rowData.get("TRNUID"));
			map.put("LOTNUM", rowData.get("LOTNUM"));
			map.put("SHPMTY", shpdhMap.get("SHPMTY"));
			List<DataMap> stockMapList = commonDao.getList(map);
			
			
			for(DataMap stock : stockMapList){
				if(qty.compareTo(BigDecimal.ZERO) <= 0)
					break;
				
				qtsiwh = (BigDecimal)stock.get("QTSIWH");
				
				if(qty.compareTo(qtsiwh) >= 0){
					qttaor = (BigDecimal.ZERO).add(qtsiwh);
					qty = qty.subtract(qtsiwh);
				}else{
					qttaor = (BigDecimal.ZERO).add(qty);
					qty = BigDecimal.ZERO;
				}
				
				taskit += 10;
				map.put("TASKKY", taskky);
				map.put("TASKIT", leftPad(taskit+"", "0", 6));
				map.put("TASKTY", "PK");
				map.put("RSNCOD", "MANU");
				map.put("STATIT", "NEW");
				map.put("QTTAOR", qttaor);
				map.put("QTCOMP", BigDecimal.ZERO);
				map.put("OWNRKY", stock.get("OWNRKY"));
				map.put("SKUKEY", stock.get("SKUKEY"));
				map.put("LOTNUM", stock.get("LOTNUM"));
				map.put("ACTCDT", " ");
				map.put("ACTCTI", " ");
				map.put("QTYUOM", qttaor);
				map.put("TKFLKY", " ");
				map.put("STEPNO", " ");
				map.put("LSTTFL", " ");				
				
				map.put("LOCASR", stock.get("LOCAKY"));
				map.put("SECTSR", stock.get("SECTID"));
				map.put("PAIDSR", stock.get("PACKID"));
				map.put("TRNUSR", stock.get("TRNUID"));
				map.put("STRUTY", stock.get("TRUNTY"));
				map.put("SMEAKY", stock.get("MEASKY"));
				map.put("SUOMKY", stock.get("UOMKEY"));
				map.put("QTSPUM", stock.get("QTPUOM"));
				map.put("SDUOKY", stock.get("DUOMKY"));
				map.put("QTSDUM", stock.get("QTDUOM"));
				
				map.put("LOCATG", stock.get("LOCATG"));
				map.put("SECTTG", stock.get("SECTID"));
				map.put("PAIDTG", stock.get("PACKID"));
				map.put("TRNUTG", stock.get("TRNUID"));
				map.put("TTRUTY", stock.get("TRUNTY"));
				map.put("TMEAKY", stock.get("MEASKY"));
				map.put("TUOMKY", stock.get("UOMKEY"));
				map.put("QTTPUM", stock.get("QTPUOM"));
				map.put("TDUOKY", stock.get("DUOMKY"));
				map.put("QTTDUM", stock.get("QTDUOM"));
				
				map.put("LOCAAC", " ");
				map.put("SECTAC", stock.get("SECTID"));
				map.put("PAIDAC", stock.get("PACKID"));
				map.put("TRNUAC", stock.get("TRNUID"));
				map.put("ATRUTY", stock.get("TRUNTY"));
				map.put("AMEAKY", stock.get("MEASKY"));
				map.put("AUOMKY", stock.get("UOMKEY"));
				map.put("QTAPUM", stock.get("QTPUOM"));
				map.put("ADUOKY", stock.get("DUOMKY"));
				map.put("QTADUM", stock.get("QTDUOM"));
				map.put("REFDKY", shpoky);
				map.put("REFDIT", shpoit);
				map.put("REFCAT", "200");
				map.put("REFDAT", date);
				map.put("PURCKY", stock.get("PURCKY"));
				map.put("PURCIT", stock.get("PURCIT"));
				map.put("ASNDKY", stock.get("ASNDKY"));
				map.put("ASNDIT", stock.get("ASNDIT"));
				map.put("RECVKY", stock.get("RECVKY"));
				map.put("RECVIT", stock.get("RECVIT"));
				map.put("SHPOKY", shpoky);
				map.put("SHPOIT", shpoit);
				map.put("GRPOKY", " ");
				map.put("GRPOIT", " ");
				map.put("SADJKY", stock.get("SADJKY"));
				map.put("SADJIT", stock.get("SADJIT"));
				map.put("SDIFKY", " ");
				map.put("SDIFIT", " ");
				map.put("PHYIKY", stock.get("PHYIKY"));
				map.put("PHYIIT", stock.get("PHYIIT"));
				map.put("DROPID", " ");
				map.put("DESC01", stock.get("DESC01"));
				map.put("DESC02", stock.get("DESC02"));
				map.put("ASKU01", stock.get("ASKU01"));
				map.put("ASKU02", stock.get("ASKU02"));
				map.put("ASKU03", stock.get("ASKU03"));
				map.put("ASKU04", stock.get("ASKU04"));
				map.put("ASKU05", stock.get("ASKU05"));
				map.put("EANCOD", stock.get("EANCOD"));
				map.put("GTINCD", stock.get("GTINCD"));
				map.put("SKUG01", stock.get("SKUG01"));
				map.put("SKUG02", stock.get("SKUG02"));
				map.put("SKUG03", stock.get("SKUG03"));
				map.put("SKUG04", stock.get("SKUG04"));
				map.put("SKUG05", stock.get("SKUG05"));
				map.put("GRSWGT", stock.get("GRSWGT"));
				map.put("NETWGT", stock.get("NETWGT"));
				map.put("WGTUNT", stock.get("WGTUNT"));
				map.put("LENGTH", stock.get("LENGTH"));
				map.put("WIDTHW", stock.get("WIDTHW"));
				map.put("HEIGHT", stock.get("HEIGHT"));
				map.put("CUBICM", stock.get("CUBICM"));
				map.put("CAPACT", stock.get("CAPACT"));
				map.put("WORKID", " ");
				map.put("WORKNM", " ");
				map.put("HHTTID", " ");
				map.put("AREAKY", stock.get("AREAKY"));
				map.put("LOTA01", stock.get("LOTA01"));
				map.put("LOTA02", stock.get("LOTA02"));
				map.put("LOTA03", stock.get("LOTA03"));
				map.put("LOTA04", stock.get("LOTA04"));
				map.put("LOTA05", stock.get("LOTA05"));
				map.put("LOTA06", stock.get("LOTA06"));
				map.put("LOTA07", stock.get("LOTA07"));
				map.put("LOTA08", stock.get("LOTA08"));
				map.put("LOTA09", stock.get("LOTA09"));
				map.put("LOTA10", stock.get("LOTA10"));
				map.put("LOTA11", stock.get("LOTA11"));
				map.put("LOTA12", stock.get("LOTA12"));
				map.put("LOTA13", stock.get("LOTA13"));
				map.put("LOTA14", stock.get("LOTA14"));
				map.put("LOTA15", stock.get("LOTA15"));
				map.put("LOTA16", stock.get("LOTA16"));
				map.put("LOTA17", stock.get("LOTA17"));
				map.put("LOTA18", stock.get("LOTA18"));
				map.put("LOTA19", stock.get("LOTA19"));
				map.put("LOTA20", stock.get("LOTA20"));
				map.put("AWMSNO", " ");
				map.put("AWMSTS", " ");
				map.put("SMANDT",  stock.get("SMANDT"));
				map.put("SEBELN",  stock.get("SEBELN"));
				map.put("SEBELP",  stock.get("SEBELP"));
				map.put("SZMBLNO", stock.get("SZMBLNO"));
				map.put("SZMIPNO", stock.get("SZMIPNO"));
				map.put("STRAID",  stock.get("STRAID"));
				map.put("SVBELN",  stock.get("SVBELN"));
				map.put("SPOSNR",  stock.get("SPOSNR"));
				map.put("STKNUM",  stock.get("STKNUM"));
				map.put("STPNUM",  stock.get("STPNUM"));
				map.put("SWERKS",  stock.get("SWERKS"));
				map.put("SLGORT",  stock.get("SLGORT"));
				map.put("SDATBG",  stock.get("SDATBG"));
				map.put("STDLNR",  stock.get("STDLNR"));
				map.put("SSORNU",  stock.get("SSORNU"));
				map.put("SSORIT",  stock.get("SSORIT"));
				map.put("SMBLNR",  stock.get("SMBLNR"));
				map.put("SZEILE",  stock.get("SZEILE"));
				map.put("SMJAHR",  stock.get("SMJAHR"));
				map.put("SXBLNR",  stock.get("SXBLNR"));
				map.put("SAPSTS",  stock.get("SAPSTS"));
				map.put("DOORKY",  " ");
				map.put("PTLT01", stock.get("LOTA01"));
				map.put("PTLT02", stock.get("LOTA02"));
				map.put("PTLT03", stock.get("LOTA03"));
				map.put("PTLT04", stock.get("LOTA04"));
				map.put("PTLT05", stock.get("LOTA05"));
				map.put("PTLT06", stock.get("LOTA06"));
				map.put("PTLT07", stock.get("LOTA07"));
				map.put("PTLT08", stock.get("LOTA08"));
				map.put("PTLT09", stock.get("LOTA09"));
				map.put("PTLT10", stock.get("LOTA10"));
				map.put("PTLT11", stock.get("LOTA11"));
				map.put("PTLT12", stock.get("LOTA12"));
				map.put("PTLT13", stock.get("LOTA13"));
				map.put("PTLT14", stock.get("LOTA14"));
				map.put("PTLT15", stock.get("LOTA15"));
				map.put("PTLT16", stock.get("LOTA16"));
				map.put("PTLT17", stock.get("LOTA17"));
				map.put("PTLT18", stock.get("LOTA18"));
				map.put("PTLT19", stock.get("LOTA19"));
				map.put("PTLT20", stock.get("LOTA20"));
				map.put("PASTKY", " ");
				map.put("ALSTKY", " ");
				map.put("SBKTXT", " ");
				map.put("TASRSN", " ");
				map.put("CREDAT", date);
				map.put("CRETIM", time);
				map.put("CREUSR", CommonConfig.SES_USER_ID_KEY);
				map.put("LMODAT", date);
				map.put("LMOTIM", time);
				map.put("LMOUSR", CommonConfig.SES_USER_ID_KEY);
				map.put("INDBZL", " ");
				map.put("INDARC", " ");
				map.put("UPDCHK", "0");				
				
				map.put("TASKKY", taskky);
				map.put("TASKIT", leftPad(taskit+"", "0", 6));
				map.put("TASKIR", "0001");
				map.put("STOKKY", stock.get("STOKKY"));
				map.put("QTSTKM", qttaor);
				map.put("QTSTKC", BigDecimal.ZERO);
				map.put("CREDAT", date);
				map.put("CRETIM", time);
				map.put("CREUSR", CommonConfig.SES_USER_ID_KEY);
				map.put("LMODAT", date);
				map.put("LMOTIM", time);
				map.put("LMOUSR", CommonConfig.SES_USER_ID_KEY);
				map.put("INDBZL", " ");
				map.put("INDARC", " ");
				map.put("UPDCHK", "0");
				
				map.setModuleCommand("WmsOutbound", "TASDI");
				commonDao.insert(map);
				
				map.setModuleCommand("WmsTask", "TASDR");
				commonDao.insert(map);
			}
		}
		
		return count;
	}
	
	@Transactional
	public int TM04Delete(DataMap map) throws SQLException {
		List<DataMap> list = map.getList("head");
		
		int count = 0;
		DataMap row = new DataMap();
		for(int i=0;i<list.size();i++){
			row = list.get(i).getMap("map");
			row.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
			
			row.setModuleCommand("WmsOutbound", "TM04IFWMS");
			commonDao.delete(row);
			
			count++;
		}
		
		return count;
	}

	

	
	@Transactional
	public String validatePikingSave(DataMap map) throws SQLException {
		String result = "OK";
		
		int headModifyIndex = -1;
		List<DataMap> itemList = null;
		if(map.containsKey("headModifyIndex")){
			headModifyIndex = map.getInt("headModifyIndex");
			itemList = map.getList("list");
		}
		
		List<DataMap> headList = map.getList("headList");
		
		DataMap row;
		DataMap rsMap;

		List<DataMap> paramItemList = new ArrayList<DataMap>();
		DataMap copy = new DataMap();
		DataMap paramItemMap = new DataMap();
		DataMap paramLocMap = new DataMap();
		
		
		for(int i=0;i<headList.size();i++){			
			if(map.containsKey("param")){
				row = new DataMap(map.getMap("param").getMap("map"));
			}else{
				row = new DataMap();
			}				
			
			map.clonSessionData(row);
			row.append(headList.get(i).getMap("map"));
			paramItemList = new ArrayList<DataMap>();
			
			if(headModifyIndex == i){	
				for(int j=0;j<itemList.size();j++){
					copy = new DataMap(itemList.get(j).getMap("map"));
					paramItemList.add(copy);
				}
			}else{
				row.setModuleCommand("WmsTask", "TASDI");
				row.put("QTY_COPY", "Y");
				List<DataMap> tasdiList = commonDao.getList(row);			
				for(int j = 0; j < tasdiList.size(); j++){
					copy = new DataMap(tasdiList.get(j));
					paramItemList.add(copy);
				}
			}
			
			// 2012.10.27 by GOKU - 오더컨펌이 되지 않은 Shipment의 피킹 완료는 할 수 없다.
			/*
			if("210".equals(row.getString("TASOTY"))    ||  "208".equals(row.getString("TASOTY")) ){
				row.setModuleCommand("WmsTask", "SHPDHDRELIN");
				rsMap = commonDao.getMap(row);
				
				if(!rsMap.get("DRELIN").toString().equals("V")){
					result = "TASK_M0034 "+ row.getString("TASKKY");
					return result;
				}
			}
			*/
			
			for(int j = 0; j < paramItemList.size(); j++){
				paramItemMap = paramItemList.get(j);
				map.clonSessionData(paramItemMap);
				
				// 이미 confirm 되었는지 검사
				if (!"00000000".equals(paramItemMap.getString("ACTCDT")) && !"".equals(paramItemMap.getString("ACTCDT"))) {
					result = "TASK_M0009 "+ row.getString("TASKKY");
					return result;
				}
				
				// 출발지번이 자동창고면 에러
				if ("V".equals(paramItemMap.getString("AUTLOC"))) {
					result = "TASK_M0018 "+ row.getString("LOCAAC");
					return result;
				}
				
				//Location 검사LocationPK locPK = new LocationPK();
				paramLocMap = new DataMap();
				paramLocMap.put("WAREKY",  "330".equals(row.getString("330"))  ? row.getString("WARETG") : paramItemMap.getString("WAREKY"));
				paramLocMap.put("LOCAKY", paramItemMap.getString("LOCAAC"));
				paramLocMap.setModuleCommand("WmsAdmin", "LOCMA");
	
				rsMap = commonDao.getMap(paramLocMap);
				
				if (rsMap == null) {
					result = "MASTER_M0507 "+ row.getString("LOCAAC");
					return result;
				}
	
				// 도착지번이 자동창고면 에러
				if ("V".equals(rsMap.getString("AUTLOC"))) {
					result = "TASK_M0024 "+ row.getString("LOCAAC");
					return result;
				}
				
				if("310".equals(row.getString("TASOTY")) && ( "SETLOC".equals(paramItemMap.getString("LOCACC")) || "RTNLOC".equals(paramItemMap.getString("LOCACC"))  ||  "SCRLOC".equals(paramItemMap.getString("LOCACC")))){
					result = "TASK_M0035 "+ row.getString("LOCAAC");
					return result;
				}
				
			}
			
		}
		
		return result;
	}
	
	/*@Transactional
	public int DL06PikingSave(DataMap map) throws SQLException {
		int headModifyIndex = -1;
		List<DataMap> itemList = null;
		if(map.containsKey("headModifyIndex")){
			headModifyIndex = map.getInt("headModifyIndex");
			itemList = map.getList("list");
		}
		
		List<DataMap> headList = map.getList("headList");
		
		DataMap row;
		int count = 0;

		List<DataMap> paramItemList = new ArrayList<DataMap>();
		DataMap paramItemMap = new DataMap();
		DataMap paramTasdrMap = new DataMap();
		DataMap copy = new DataMap();
		
		for(int i=0;i<headList.size();i++){			
			if(map.containsKey("param")){
				row = new DataMap(map.getMap("param").getMap("map"));
			}else{
				row = new DataMap();
			}				
			
			map.clonSessionData(row);
			row.append(headList.get(i).getMap("map"));
			paramItemList = new ArrayList<DataMap>();
			
			if(headModifyIndex == i){	
				for(int j=0;j<itemList.size();j++){
					copy = new DataMap(itemList.get(j).getMap("map"));
					paramItemList.add(copy);
				}
			}else{
				row.setModuleCommand("WmsTask", "TASDI");
				row.put("QTY_COPY", "Y");
				List<DataMap> tasdiList = commonDao.getList(row);			
				for(int j = 0; j < tasdiList.size(); j++){
					copy = new DataMap(tasdiList.get(j));
					paramItemList.add(copy);
				}
			}


			//insert
			for(int j = 0; j < paramItemList.size(); j++){
				paramItemMap = paramItemList.get(j);

				//remove
				paramItemMap.setModuleCommand("WmsTask", "TASDIDEL");
				commonDao.delete(paramItemMap);
				
				
				paramItemMap.setModuleCommand("WmsTask", "TASDIEND");
				paramItemMap.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));

				// "FPC" 작업수량 = 작업완료수량  
				// "PPC" 작업수량 > 작업완료수량
				// "OPC" 작업수량 < 작업완료수량 
				int STAUES = Integer.parseInt(paramItemMap.getString("QTTAOR") )- Integer.parseInt(paramItemMap.getString("QTCOMP"));
				if (STAUES == 0) {
					paramItemMap.put("STATIT","FPC");
				} else if (STAUES == 1) {
					paramItemMap.put("STATIT","PPC");
				} else if (STAUES == -1) {
					paramItemMap.put("STATIT","OPC");
				}
				commonDao.insert(paramItemMap);
				


				paramItemMap.put("ERRNUM",0);
				paramItemMap.put("ERRMSG", "");
				paramItemMap.setModuleCommand("WmsOutbound", "SZPINSTASDR");		
				commonDao.update(paramItemMap);
				
			}
			count++;
		}
		
		return count;	
	}*/
	
	@Transactional
	public int DL06PikingSave(DataMap map) throws SQLException {
		int headModifyIndex = -1;
		List<DataMap> itemList = null;
		if(map.containsKey("headModifyIndex")){
			headModifyIndex = map.getInt("headModifyIndex");
			itemList = map.getList("list");
		}
		
		List<DataMap> headList = map.getList("headList");
		
		DataMap row;
		int count = 0;

		List<DataMap> paramItemList = new ArrayList<DataMap>();
		DataMap paramItemMap = new DataMap();
		DataMap paramTasdrMap = new DataMap();
		DataMap copy = new DataMap();
		
		for(int i=0;i<headList.size();i++){			
			if(map.containsKey("param")){
				row = new DataMap(map.getMap("param").getMap("map"));
			}else{
				row = new DataMap();
			}				
			
			map.clonSessionData(row);
			row.append(headList.get(i).getMap("map"));
			paramItemList = new ArrayList<DataMap>();
			
			if(headModifyIndex == i){	
				for(int j=0;j<itemList.size();j++){
					copy = new DataMap(itemList.get(j).getMap("map"));
					paramItemList.add(copy);
				}
			}else{
				row.setModuleCommand("WmsTask", "TASDI");
				row.put("QTY_COPY", "Y");
				List<DataMap> tasdiList = commonDao.getList(row);			
				for(int j = 0; j < tasdiList.size(); j++){
					copy = new DataMap(tasdiList.get(j));
					paramItemList.add(copy);
				}
			}


			//insert
			for(int j = 0; j < paramItemList.size(); j++){
				paramItemMap = paramItemList.get(j);
				paramItemMap.setModuleCommand("WmsTask", "STKKYPUTFIND");
				DataMap dtMap = commonDao.getMap(paramItemMap);

				//remove
				paramItemMap.setModuleCommand("WmsTask", "TASDIDEL");
				commonDao.delete(paramItemMap);
				
				
				paramItemMap.setModuleCommand("WmsTask", "TASDIEND");
				paramItemMap.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));

				// "FPC" 작업수량 = 작업완료수량  
				// "PPC" 작업수량 > 작업완료수량
				// "OPC" 작업수량 < 작업완료수량 
			   /*
				* 2016.2.21 junghyojin 작업수량 정수형 처리를 위하여 주석 후 double으로 변경 처리함. 
				* int STAUES = Integer.parseInt(paramItemMap.getString("QTTAOR") )- Integer.parseInt(paramItemMap.getString("QTCOMP"));
				* if (STAUES == 0) {
				* 	paramItemMap.put("STATIT","FPC");
				* } else if (STAUES == 1) {
				* 	paramItemMap.put("STATIT","PPC");
				* } else if (STAUES == -1) {
				*	paramItemMap.put("STATIT","OPC");
				* }
				*/
				BigDecimal p_qttaor = new BigDecimal(paramItemMap.getString("QTTAOR"));
				BigDecimal p_qtcomp = new BigDecimal(paramItemMap.getString("QTCOMP"));
				
				BigDecimal p_STAUES = p_qttaor.subtract(p_qtcomp);
				
				log.debug(":::::::::::DL06PikingSave.p_STAUES::::::"+p_STAUES.signum());					
				if (0 == p_STAUES.signum() ){
					paramItemMap.put("STATIT","FPC");
				} else if (1 == p_STAUES.signum() ) {
					paramItemMap.put("STATIT","PPC");
				} else if (-1 == p_STAUES.signum() ) {
					paramItemMap.put("STATIT","OPC");
				}										
				
				commonDao.insert(paramItemMap);
				paramTasdrMap = new DataMap();

				
				paramTasdrMap.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
				paramTasdrMap.put("STOKKY", dtMap.getString("SRCSKY"));
				paramTasdrMap.put("LMODAT", paramItemMap.getString("LMODAT"));
				paramTasdrMap.put("LMOTIM", paramItemMap.getString("LMOTIM"));
				paramTasdrMap.put("LMOUSR", paramItemMap.getString("LMOUSR"));
				paramTasdrMap.put("TASKKY", dtMap.getString("TASKKY"));
				paramTasdrMap.put("TASKIT", dtMap.getString("TASKIT"));
				paramTasdrMap.put("QTSTKC", paramItemMap.getString("QTCOMP"));
				paramTasdrMap.put("QTSTKM", dtMap.getString("QTSTKM"));

				paramTasdrMap.setModuleCommand("WmsTask", "TASDREND");			
				commonDao.insert(paramTasdrMap);
			}
			count++;
		}
		
		return count;	
	}
	
	
	
	
	@Transactional
	public int DeleteTM07(DataMap map) throws SQLException {
		
		List<DataMap> head = map.getList("head");
		
		int count = 0;
		DataMap row = new DataMap();
	
		for( int i = 0 ; i < head.size() ; i++ ){
			row = head.get(i).getMap("map");
			
			row.setModuleCommand("WmsOutbound", "TM07");
			row.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
			commonDao.delete(row);
			
			count++;
			
		}
		return count;
	}
	@Transactional
	public DataMap SaveTM03(DataMap map) throws SQLException {
		List<DataMap> headTemp = map.getList("head"); 
		DataMap head = headTemp.get(0).getMap("map");
		List<DataMap> list = map.getList("list");
		
		int itemCount=0;
		int count = 0;
		DataMap row = new DataMap();
		DataMap item = new DataMap();
		
		// Added by Yun
		String num_VBELN = "WMS" + wmsService.getNumSeq("NR-VBELN").substring(3);
		// Added by Yun
		
		for(int i=0;i<list.size();i++){
			row = list.get(i).getMap("map");
			row.setModuleCommand("WmsOutbound", "TM05");
			row.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
			row.put(CommonConfig.SES_USER_OWNER_KEY, map.get(CommonConfig.SES_USER_OWNER_KEY));
			
			row.put("MANDT", "110" );
			row.put("SEQNO", wmsService.getNumSeq("NR-IF113"));
//			row.put("VBELN", head.getString("VBELN") );
			row.put("VBELN", num_VBELN );
			itemCount += 1;
			String snum = String.valueOf(itemCount);
			row.put( "POSNR", snum );

			row.put("BWART", head.getString("BWART") );
			row.put("STATUS", "A" );
			row.put("IFFLG", "N" );
			row.put("WADAT", head.getString("ZEKKO_AEDAT"));
			row.put("PTNRKY", head.getString("PTNRKY"));
			row.put("MEINS", row.get("UOMKEY") );
			row.put("WAREKY", head.getString("WAREKY") );
			
			commonDao.update(row);

/*			
			DataMap vbelnMap = new DataMap("WmsOutbound", "SETVBELN");
			vbelnMap.put("BWART", head.getString("BWART"));
			String vbelnext =(String)commonDao.getMap(vbelnMap).getString("VBELN");
			
			item.put("VBELN", row.getString("VBELN"));
			item.put("POSNR", row.getString("POSNR"));
			item.put("VBELNEXT", vbelnext);
			item.put("VWAREKY", head.getString("WAREKY"));
			item.put("VSEQNO", wmsService.getNumSeq("NR-IF113"));
 */
		}
//		item.setModuleCommand("WmsOutbound", "TM05G");
//		commonDao.update(item);


		DataMap rsMap = new DataMap();
		StringBuilder sb = new StringBuilder();
		
		map.setModuleCommand("WmsOutbound", "TM05H");
//		map.put("VBELN", head.getString("VBELN") );
		map.put("VBELN", num_VBELN );
		
		List dataList = commonDao.getList(map);
		
		rsMap.put("data", dataList);
		
		return rsMap;
	}

	@Transactional
	public DataMap SaveTM05(DataMap map) throws SQLException {
		List<DataMap> headTemp = map.getList("head"); 
		DataMap head = headTemp.get(0).getMap("map");
		List<DataMap> list = map.getList("list");
		
		int itemCount=0;
		int count = 0;
		DataMap row = new DataMap();
		DataMap item = new DataMap();
		
		// Added by Yun
		String num_VBELN = "WMS" + wmsService.getNumSeq("NR-VBELN").substring(3);
		// Added by Yun
		
		for(int i=0;i<list.size();i++){
			row = list.get(i).getMap("map");
			row.setModuleCommand("WmsOutbound", "TM05");
			row.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
			row.put(CommonConfig.SES_USER_OWNER_KEY, map.get(CommonConfig.SES_USER_OWNER_KEY));
			
			row.put("MANDT", "110" );
			row.put("SEQNO", wmsService.getNumSeq("NR-IF113"));
//			row.put("VBELN", head.getString("VBELN") );
			row.put("VBELN", num_VBELN);
			itemCount += 1;
			String snum = String.valueOf(itemCount);
			row.put( "POSNR", snum );
			
			row.put("BWART", head.getString("BWART") );
			
			row.put("STATUS", "A" );
			row.put("IFFLG", "N" );
			row.put("WADAT", head.getString("ZEKKO_AEDAT"));
			row.put("PTNRKY", head.getString("PTNRKY"));
			row.put("MEINS", row.get("UOMKEY") );
			row.put("WAREKY", head.getString("WAREKY") );
			
			commonDao.update(row);

			// blocked by Yun
/*
			String vseqno = wmsService.getNumSeq("NR-IF113");
			
			DataMap vbelnMap = new DataMap("WmsOutbound", "SETVBELN");
			vbelnMap.put("BWART", head.getString("BWART"));
			String vbelnext =(String)commonDao.getMap(vbelnMap).getString("VBELN");
			
			item.put("VBELN", row.getString("VBELN"));
			item.put("POSNR", row.getString("POSNR"));
			item.put("VBELNEXT", vbelnext);
			item.put("VWAREKY", head.getString("WAREKY"));
			item.put("VSEQNO", vseqno);
 */
			// blocked by Yun
		}
//		item.setModuleCommand("WmsOutbound", "TM05G");
//		commonDao.update(item);


		DataMap rsMap = new DataMap();
		StringBuilder sb = new StringBuilder();
		
		map.setModuleCommand("WmsOutbound", "TM05H");
//		map.put("VBELN", head.getString("VBELN") );
		map.put("VBELN", num_VBELN );
		
		List dataList = commonDao.getList(map);
		
		rsMap.put("data", dataList);
		
		return rsMap;
	}

	@Transactional
	public DataMap SaveTM06(DataMap map) throws SQLException {
		List<DataMap> headTemp = map.getList("head"); 
		DataMap head = headTemp.get(0).getMap("map");
		List<DataMap> list = map.getList("list");
		
		map.put("WAREKY", head.get("WAREKY"));

		int count = 0;
		int itemCount=0;
		DataMap row = new DataMap();
		
		for(int i=0;i<list.size();i++){
			row = list.get(i).getMap("map");
			row.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
			row.put(CommonConfig.SES_USER_OWNER_KEY, map.get(CommonConfig.SES_USER_OWNER_KEY));
			row.setModuleCommand("WmsOutbound", "TM06");
			row.put("MANDT", "110" );
			
			row.put("SEQNO", wmsService.getNumSeq("NR-IF113"));
			row.put("EBELN", head.getString("EBELN") );
			
			itemCount += 1;
			String snum = String.valueOf(itemCount);
			row.put( "EBELP", snum );
			row.put("LIFNR", head.getString("PTNRKY") );
			row.put("BWART", head.getString("BWART") );
			
			row.put("STATUS", "A" );
			row.put("IFFLG", "N" );
			row.put("WAREKY", head.getString("WAREKY") );
			row.put("DEPTID1", head.getString("PTNRKY") );
			
			commonDao.insert(row);
					
			count++;
		}


		DataMap rsMap = new DataMap();
		StringBuilder sb = new StringBuilder();
		
		map.setModuleCommand("WmsOutbound", "TM06H");
		map.put("EBELN", head.getString("EBELN") );
		
		List dataList = commonDao.getList(map);
		
		rsMap.put("data", dataList);
		
		return rsMap;
		
	
	}
	
	@Transactional
	public DataMap saveShpd(DataMap map) throws SQLException {
		
		int headModifyIndex = -1;
		List<DataMap> itemList = null;
		if(map.containsKey("headModifyIndex")){
			headModifyIndex = map.getInt("headModifyIndex");
			itemList = map.getList("list");
		}
		
		DataMap rsMap = new DataMap();
		
		List<DataMap> headList = map.getList("headList");
		
		DataMap row;
		
		List docNumList = new ArrayList();
		
		for(int i=0;i<headList.size();i++){			
			if(map.containsKey("param")){
				row = new DataMap(map.getMap("param").getMap("map"));
			}else{
				row = new DataMap();
			}				
			
			map.clonSessionData(row);
			row.append(headList.get(i).getMap("map"));
			
			String docNum;
			int itemCount = 0;
			
			if("".equals(row.getString("SHPOKY").trim())){
				docNum = wmsService.getDocSeq(row.getString("DOCUTY"));
				row.put("SHPOKY", docNum);
				row.setModuleCommand("WmsOutbound", "SHPDH");
				commonDao.insert(row);
				if(headModifyIndex == i){				
					row.setModuleCommand("WmsOutbound", "SHPDI");
					for(int j=0;j<itemList.size();j++){
						row.append(itemList.get(j).getMap("map"));
						
						itemCount += 10;
						String snum = String.valueOf(itemCount);
						String inum = String.valueOf("000000").substring(0,(6-snum.length()))+snum;
						row.put("SHPOKY", docNum);
						row.put("SHPOIT", inum);
						commonDao.insert(row);
					}
				}else{
					row.setModuleCommand("WmsOutbound", "SHPDIALL");
					commonDao.insert(row);			
				}
			}else{
				docNum = row.getString("SHPOKY");
				row.setModuleCommand("WmsOutbound", "SHPDHORG");
				commonDao.update(row);
				
				if(headModifyIndex == i){				
					row.setModuleCommand("WmsOutbound", "SHPDIORG");
					for(int j=0;j<itemList.size();j++){
						row.append(itemList.get(j).getMap("map"));
						commonDao.update(row);
					}
				}
			}
			docNumList.add(docNum);
			
			if(row.getString("SHPMTY").toString().equals("299")){
				row.setModuleCommand("WmsOutbound", "IF113STKNUM");
				commonDao.update(row);
			}
			
			if(!row.getString("DRELIN").toString().equals("V")){
				row.put("DRELIN", "V");
				row.setModuleCommand("WmsOutbound", "SHPDH");
				commonDao.update(row);
				
				if(row.getString("SHPMTY").toString().equals("299")){
					row.setModuleCommand("WmsOutbound", "IF113PROC");
					commonDao.getMap(row);
				}
			}
			
			if(map.containsKey("batch")){
				row.setModuleCommand("WmsOutbound", "BATCHALLOCATION");
				
				commonDao.getMap(row);
			}
		}
		
		StringBuilder sb = new StringBuilder();
		for(int i=0;i<docNumList.size();i++){
			if(i != 0){
				sb.append(",");
			}
			sb.append("'").append(docNumList.get(i)).append("'");
		}
		
		map.setModuleCommand("WmsOutbound", "DL04HEAD");
		map.put("SHPOKY", sb.toString());
		
		List dataList = commonDao.getList(map);
		
		rsMap.put("data", dataList);
		
		return rsMap;
	}
	
	@Transactional
	public DataMap deleteOrder(DataMap map) throws SQLException {
		int headModifyIndex = -1;
		List<DataMap> itemList = null;
		if(map.containsKey("headModifyIndex")){
			headModifyIndex = map.getInt("headModifyIndex");
			itemList = map.getList("list");
		}
		
		DataMap rsMap = new DataMap();
		
		List<DataMap> headList = map.getList("headList");
		
		DataMap row;
		
		for(int i=0;i<headList.size();i++){			
			if(map.containsKey("param")){
				row = new DataMap(map.getMap("param").getMap("map"));
			}else{
				row = new DataMap();
			}				
			
			map.clonSessionData(row);
			row.append(headList.get(i).getMap("map"));
			row.setModuleCommand("WmsOutbound", "IFWMS113");
			
			if(headModifyIndex == i){				
				for(int j=0;j<itemList.size();j++){
					row.append(itemList.get(j).getMap("map"));
					commonDao.update(row);
				}
			}else{
				commonDao.update(row);		
			}
		}
		
		return rsMap;
	}
	
	@Transactional
	public DataMap dl04Procall(DataMap map) throws SQLException {
		int headModifyIndex = -1;
		List<DataMap> itemList = null;
		if(map.containsKey("headModifyIndex")){
			headModifyIndex = map.getInt("headModifyIndex");
			itemList = map.getList("list");
		}
		
		DataMap rsMap = new DataMap();
		
		List<DataMap> headList = map.getList("headList");
		
		DataMap row = new DataMap();
		
		List docNumList = new ArrayList();
		
		for(int i=0;i<headList.size();i++){
			if(map.containsKey("param")){
				row = new DataMap(map.getMap("param").getMap("map"));
			}else{
				row = new DataMap();
			}				
			map.clonSessionData(row);
			row.append(headList.get(i).getMap("map"));
			docNumList.add(headList.get(i).getMap("map").get("SHPOKY"));

			
			if(row.getString("SHPMTY").toString().equals("299")){
				row.setModuleCommand("WmsOutbound", "IF113STKNUM");
				commonDao.update(row);
			}
			
			if(!row.getString("DRELIN").toString().equals("V")){
				row.put("DRELIN", "V");
				row.setModuleCommand("WmsOutbound", "SHPDH");
				commonDao.update(row);
				
				if(row.getString("SHPMTY").toString().equals("299")){
					row.setModuleCommand("WmsOutbound", "IF113PROC");
					commonDao.getMap(row);
				}
			}
			
			if(map.containsKey("batch")){
				row.setModuleCommand("WmsOutbound", "BATCHALLOCATION");
				
				commonDao.getMap(row);
			}
			
		}
		
		StringBuilder sb = new StringBuilder();
		for(int i=0;i<docNumList.size();i++){
			if(i != 0){
				sb.append(",");
			}
			sb.append("'").append(docNumList.get(i)).append("'");
		}
		
		map.setModuleCommand("WmsOutbound", "DL04HEAD");
		map.put("SHPOKY", sb.toString());
		
		List dataList = commonDao.getList(map);
		
		rsMap.put("data", dataList);
		
		return rsMap;
	}
	

	
	@Transactional
	public String validateSendEcms(DataMap map) throws Exception {
		String result = "OK";
		
		int headModifyIndex = -1;
		List<DataMap> itemList = null;
		if(map.containsKey("headModifyIndex")){
			headModifyIndex = map.getInt("headModifyIndex");
			itemList = map.getList("list");
		}
		
		List<DataMap> headList = map.getList("headList");
		
		DataMap row;
		DataMap copy = new DataMap();
		List<DataMap> paramItemList = new ArrayList<DataMap>();
		
		for(int i=0;i<headList.size();i++){			
			if(map.containsKey("param")){
				row = new DataMap(map.getMap("param").getMap("map"));
			}else{
				row = new DataMap();
			}				
			
			map.clonSessionData(row);
			row.append(headList.get(i).getMap("map"));
			
			if(row.get("OBPROTCT").equals("V")){
				throw new Exception("매출처출고불허 상태입니다");
			}
			
			paramItemList = new ArrayList<DataMap>();
			if(headModifyIndex == i){	
				for(int j=0;j<itemList.size();j++){
					copy = new DataMap(itemList.get(j).getMap("map"));
					paramItemList.add(copy);
				}
			}else{
				row.setModuleCommand("WmsOutbound", "DL08Sub");
				List<DataMap> dl08subList = commonDao.getList(row);			
				for(int j = 0; j < dl08subList.size(); j++){
					copy = new DataMap(dl08subList.get(j));
					paramItemList.add(copy);
				}
			}

			//Validation check
			// (PPC, FPC) && (출하완료수량 <= 피킹수량) && (출하완료수량 <= 지시수량) Validation
	 		StringBuffer sb = new StringBuffer();
	 		
			for(int j=0;j<paramItemList.size();j++){
				copy = paramItemList.get(j);
				if(sb.length() > 0){
					sb.append(" UNION ALL ");
				}
				
				sb.append("SELECT '").append(copy.getString("SHPOKY")).append("' AS SHPOKY, ");
				sb.append("'").append(copy.getString("SHPOIT")).append("' AS SHPOIT, ");
				sb.append("'").append(copy.getString("QTSHPD")).append("' AS QTSHPD ");
				sb.append(" FROM DUAL ");
			}

			if(sb.length() > 0){
				row.put("APPENDQUERY", sb.toString());
				row.setModuleCommand("WmsOutbound", "VALIDDL08");
				List<DataMap> valiList = commonDao.getList(row);
				
				for(int k=0; k< valiList.size(); k++){
					DataMap dtMap = valiList.get(k);
					
					if( !" ".equals(dtMap.getString("RESULTMSG"))){
						result = dtMap.getString("RESULTMSG");
						return result;
					}
					
				}
			}

			// 1. 완료처리하지 않은  TASK 정보가 있는지 확인.
			row.setModuleCommand("WmsOutbound", "CNTTASK");
			int count =  commonDao.getMap(row).getInt("CNT");
			if(count > 0){
				result = "OUT_M107 "+ row.getString("SHPOKY");
				return result;
			}
		}
		
		return result;
	}
	
	@Transactional
	public DataMap sendEcms(DataMap map) throws SQLException {
		DataMap rsMap = new DataMap();
		Connection conn = sqlMapClient.getDataSource().getConnection();
 	    conn.setAutoCommit(false);
 	    SqlMapSession session = sqlMapClient.openSession(conn);
		
 	    try{
 	    	int headModifyIndex = -1;
 	    	List<DataMap> itemList = null;
 	    	if(map.containsKey("headModifyIndex")){
 	    		headModifyIndex = map.getInt("headModifyIndex");
 	    		itemList = map.getList("list");
 	    	}
 	    	
 	    	List<DataMap> headList = map.getList("headList");
 	    	
 	    	DataMap row;
 	    	
 	    	List docNumList = new ArrayList();
 	    	List<DataMap> paramItemList = new ArrayList<DataMap>();
 	    	DataMap copy = new DataMap();
 	    	DataMap itemMap = new DataMap();
 	    	
 	    	for(int i=0;i<headList.size();i++){			
 	    		if(map.containsKey("param")){
 	    			row = new DataMap(map.getMap("param").getMap("map"));
 	    		}else{
 	    			row = new DataMap();
 	    		}				
 	    		
 	    		map.clonSessionData(row);
 	    		row.append(headList.get(i).getMap("map"));
 	    		docNumList.add(headList.get(i).getMap("map").get("SHPOKY"));
 	    		
 	    		paramItemList = new ArrayList<DataMap>();
 	    		if(headModifyIndex == i){	
 	    			for(int j=0;j<itemList.size();j++){
 	    				copy = new DataMap(itemList.get(j).getMap("map"));
 	    				paramItemList.add(copy);
 	    			}
 	    		}else{
 	    			row.setModuleCommand("WmsOutbound", "DL08Sub");
 	    			List<DataMap> dl08subList = commonDao.getList(row);			
 	    			for(int j = 0; j < dl08subList.size(); j++){
 	    				copy = new DataMap(dl08subList.get(j));
 	    				paramItemList.add(copy);
 	    			}
 	    		}
 	    		
 	    		for(int j=0;j<paramItemList.size();j++){
 	    			itemMap = paramItemList.get(j);
 	    			map.clonSessionData(itemMap);
 	    			
 	    			itemMap.put("SLAND1", row.get("SLAND1"));
 	                /*itemMap.put("NAME01", row.get("NAME01"));*/
 	                itemMap.put("SBKTXT", row.get("SBKTXT"));
 	    			
 	    			itemMap.setModuleCommand("WmsOutbound", "DL08SHPDI");
 	    			commonDao.update(itemMap);
 	    		}
 	    		
 	    		row.setModuleCommand("WmsOutbound", "DL08SHPDH");
 	    		commonDao.update(row);
 	    		
 	    		// 5. 전송 프로시저 호출
 	    		row.put("DOCUKY", row.get("SHPOKY"));
 	    		row.put("DOFLAG", "Z");
 	    		row.setModuleCommand("WmsOutbound", "CALL_AIRWMS_DOCUMENT_PROCESS");
    			commonDao.getMap(row);
 	    	}
 	    	
 	    	conn.commit();
 	    }catch(Exception e){
	        conn.rollback();
			log.debug(e.getMessage());
			throw new SQLException(e.getMessage());
		}finally{
 	        if(session != null){ session.close(); }
 	        if(conn != null){ conn.close(); }      
		}
 	    rsMap.put("ERRNUM", 0);
		rsMap.put("MSG", "OK");
	
		return rsMap;
	}
	
	@Transactional
	public int savePrtseq(DataMap map) throws SQLException {
		List<DataMap> list = map.getList("head");
		int count = 0;
		
		DataMap row;
		for(int i=0;i<list.size();i++){
		    row = list.get(i).getMap("map");
			row.setModuleCommand("WmsOutbound", "PRTLG");		
			row.put("PRTSEQ", map.get("PRTSEQ"));	
			
			row.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
			row.put(CommonConfig.SES_USER_OWNER_KEY, map.get(CommonConfig.SES_USER_OWNER_KEY));
			commonDao.insert(row);
			
			count ++;
		}
		
		return count;
	}
	
	@Transactional
	public int savePrtseq2(DataMap map) throws SQLException {
		List<DataMap> list = map.getList("head");
		int count = 0;
		
		DataMap row;
		for(int i=0;i<list.size();i++){
		    row = list.get(i).getMap("map");
			row.setModuleCommand("WmsOutbound", "PRTLGPICK");		
			row.put("PRTSEQ", map.get("PRTSEQ"));	
			
			row.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
			row.put(CommonConfig.SES_USER_OWNER_KEY, map.get(CommonConfig.SES_USER_OWNER_KEY));
			commonDao.insert(row);
			
			count ++;
		}
		
		return count;
	}
	
	@Transactional
	public int saveDL04(DataMap map) throws SQLException {
		List<DataMap> list = map.getList("head");
		int count = 0;
		
		DataMap row;
		for(int i=0;i<list.size();i++){
			row = list.get(i).getMap("map");
			row.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
			row.put(CommonConfig.SES_USER_OWNER_KEY, map.get(CommonConfig.SES_USER_OWNER_KEY));
			row.put(CommonConfig.SES_USER_WHAREHOUSE_KEY, map.get(CommonConfig.SES_USER_WHAREHOUSE_KEY));
			
			commonDao.update("WmsOutbound.DL04", row);
			count ++;
		}
		return count;
	}
	
	@Transactional
	public int saveDL04Sub(DataMap map) throws SQLException {
		List<DataMap> list = map.getList("list");
		int count = 0;
		
		DataMap row;
		for(int i=0;i<list.size();i++){
			row = list.get(i).getMap("map");
			row.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
			row.put(CommonConfig.SES_USER_OWNER_KEY, map.get(CommonConfig.SES_USER_OWNER_KEY));
			row.put(CommonConfig.SES_USER_WHAREHOUSE_KEY, map.get(CommonConfig.SES_USER_WHAREHOUSE_KEY));
			
			commonDao.update("WmsOutbound.DL04Sub", row);
			count ++;
		}
		return count;
	}
	
	@Transactional
	public DataMap AssignDL04(DataMap map) throws SQLException {
		//DataMap head = map.getMap("head");
		List<DataMap> head = map.getList("head");
		int count = 0;
		map.put("AREAKY", head.get(0).getMap("map").getString("AREAKY"));
		String wareky = (String)map.get(CommonConfig.SES_USER_WHAREHOUSE_KEY);
		
		map.setModuleCommand("WmsOutbound", "SEQSTKNUM");
		int stknum = (Integer)commonDao.getObject(map);
	    map.put("STKNUM", stknum);
		DataMap row;
		for(int i=0;i<head.size();i++){
			row = head.get(i).getMap("map");
			row.put("STKNUM", stknum);
			row.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
			row.put(CommonConfig.SES_USER_OWNER_KEY, map.get(CommonConfig.SES_USER_OWNER_KEY));
			commonDao.update("WmsOutbound.DL04HEAD", row);
			
			count ++;
		}
		
		DataMap rsMap = null;
		if(wareky.equals("WH00")){
			rsMap = commonDao.getMap("WmsOutbound.ALLOCATION_VALID", map);
			if(rsMap != null)
				return rsMap;
			commonDao.getMap("WmsOutbound.ALLOC_WH00_PROCALL", map);
		}else{
			commonDao.getMap("WmsOutbound.ALLOC_PROCALL", map);
		}
		
		rsMap = new DataMap();
		rsMap.put("SHPOKY", "OK");
		
		return rsMap;
	}
	
	@Transactional
	public int UnallocateDL04(DataMap map) throws SQLException {
		List<DataMap> head = map.getList("head");
		int count = 0;
		
		DataMap row;
		for(int i=0;i<head.size();i++){
			row = head.get(i).getMap("map");
			row.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
			row.put(CommonConfig.SES_USER_OWNER_KEY, map.get(CommonConfig.SES_USER_OWNER_KEY));
			row.put(CommonConfig.SES_USER_WHAREHOUSE_KEY, map.get(CommonConfig.SES_USER_WHAREHOUSE_KEY));
			
			commonDao.delete("WmsOutbound.DL04REMOVE", row);
			count ++;
		}
		return count;
	}
	
	@Transactional
	public int CompleteDL04(DataMap map) throws SQLException {
		List<DataMap> list = map.getList("head");
		int count = 0;
		
		DataMap row;
		for(int i=0;i<list.size();i++){
			row = list.get(i).getMap("map");
			row.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
			row.put(CommonConfig.SES_USER_OWNER_KEY, map.get(CommonConfig.SES_USER_OWNER_KEY));
			row.put(CommonConfig.SES_USER_WHAREHOUSE_KEY, map.get(CommonConfig.SES_USER_WHAREHOUSE_KEY));
			
			commonDao.getMap("WmsOutbound.SHPDPROCALL", row);
			count ++;
		}
		return count;
	}
	
	@Transactional
	public String DL09CancelShipment(DataMap map) throws SQLException {
		List<DataMap> list = map.getList("head");
		
		// Validation
		StringBuffer sb = new StringBuffer();
		for(DataMap head : list){
			if(sb.length() > 0)
				sb.append(" UNION ALL\n ");
			
			sb.append(" SELECT '").append(head.getMap("map").get("SHPOKY")).append("' AS SHPOKY FROM DUAL ");
		}
		
		map.setModuleCommand("WmsOutbound", "SHIPPING_CANCEL"); // 쿼리키값 넣을것
		map.put("APPEND_QUERY", sb.toString());
		List<DataMap> validList = commonDao.getValidation(map);
		if(validList.size() > 0){
			DataMap valid = validList.get(0);
			return valid.getString("RESULTMSG");
		}
		
		DataMap row;
		for(int i=0;i<list.size();i++){
			row = list.get(i).getMap("map");
			row.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
			row.put(CommonConfig.SES_USER_OWNER_KEY, map.get(CommonConfig.SES_USER_OWNER_KEY));
			row.put(CommonConfig.SES_USER_WHAREHOUSE_KEY, map.get(CommonConfig.SES_USER_WHAREHOUSE_KEY));
			row.put("DOCUKY", row.get("SHPOKY"));
			row.put("DOFLAG", "C");
			//commonDao.getMap("WmsOutbound.CALL_SHIPPING_CANCEL_PROC", row);
			commonDao.getMap("WmsOutbound.CALL_AIRWMS_DOCUMENT_PROCESS", row);
		}
		
		return "OK";
	}
	
	@Transactional
	public int CompleteDL06(DataMap map) throws SQLException {
		List<DataMap> list = map.getList("head");
		int count = 0;
		DataMap row;
		for(int i=0;i<list.size();i++){
			row = list.get(i).getMap("map");
			map.putAll(row);
			commonDao.getMap("WmsOutbound.DL06PROCALL", row);     
			count++;
		}
		return count;
	}
	
	@Transactional
	public int CompleteDL16(DataMap map) throws SQLException {
		List<DataMap> list = map.getList("list");
       
		SimpleDateFormat fmDate = new SimpleDateFormat("yyyyMMdd", Locale.KOREA);
		String date = fmDate.format(new Date());
		SimpleDateFormat fmTime = new SimpleDateFormat("HHmmss", Locale.KOREA);
		String time = fmTime.format(new Date());
       
		int count = 0;
		DataMap row;
		DataMap searchtasdi = new DataMap();
		DataMap searchtasdr = new DataMap();
		DataMap data;
		for(int i=0;i<list.size();i++){
		  // 1. TASDI/R SELECT///////////////////////////
			row = list.get(i).getMap("map");
			map.put("TASKKY", row.get("TASKKY"));
			map.put("TASKIT", row.get("TASKIT"));
			  
			map.setModuleCommand("WmsOutbound", "SEARCHTASDI");
			searchtasdi = commonDao.getMap(map);
			  
			map.setModuleCommand("WmsOutbound", "SEARCHTASDR");
			searchtasdr = commonDao.getMap(map);
			  
			//2. 재고찾기//////////////////////////////////////
			searchtasdr.setModuleCommand("WmsOutbound", "STKKYFIND");
	        data = commonDao.getMap(searchtasdr);
			  
			//3. TASDI DELETE////////////////////////////////
	        searchtasdi.setModuleCommand("WmsOutbound", "TASDIDEL");
			commonDao.delete(searchtasdi);
			
			//4.TASDI/R INSERT////////////////////////////////
			searchtasdi.put("LOCAAC", searchtasdi.get("LOCATG"));
			searchtasdi.put("ACTCDT", date);
			searchtasdi.put("ACTCTI", time);
			searchtasdi.put("QTCOMP", row.get("QTCOMP"));
			searchtasdi.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
			searchtasdi.setModuleCommand("WmsOutbound", "TASDIEND");
			commonDao.insert(searchtasdi);
			
			searchtasdr.put("QTSTKC", row.get("QTCOMP"));
			searchtasdr.put("STOKKY", data.get("SRCSKY"));
			searchtasdr.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
			searchtasdr.setModuleCommand("WmsOutbound", "TASDREND");
			commonDao.insert(searchtasdr);
			      
			count++;
		}
		return count;
	}
	
	@Transactional
	public String PickingCancelDL07(DataMap map) throws SQLException {
		List<DataMap> list = map.getList("head");
       
		SimpleDateFormat fmDate = new SimpleDateFormat("yyyyMMdd", Locale.KOREA);
		String date = fmDate.format(new Date());
		SimpleDateFormat fmTime = new SimpleDateFormat("HHmmss", Locale.KOREA);
		String time = fmTime.format(new Date());
       
		// Validation
		StringBuffer sb = new StringBuffer();
		for(DataMap item : list){
			if(sb.length() > 0)
				sb.append(" UNION ALL\n ");
			
			sb.append(" SELECT '").append(item.getMap("map").get("TASKKY")).append("' AS TASKKY, ");
			sb.append("        '").append(item.getMap("map").get("TASKIT")).append("' AS TASKIT FROM DUAL ");
		}
		
		map.setModuleCommand("WmsOutbound", "PICKING_CANCEL"); // 쿼리키값 넣을것
		map.put("APPEND_QUERY", sb.toString());
		List<DataMap> validList = commonDao.getValidation(map);
		if(validList.size() > 0){
			DataMap valid = validList.get(0);
			return valid.getString("RESULTMSG");
		}
		
		DataMap row;
		DataMap itRow;
		for(int i=0;i<list.size();i++){
			row = list.get(i).getMap("map");
			
			row.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
			row.put(CommonConfig.SES_USER_OWNER_KEY, map.get(CommonConfig.SES_USER_OWNER_KEY));
			row.put(CommonConfig.SES_USER_WHAREHOUSE_KEY, map.get(CommonConfig.SES_USER_WHAREHOUSE_KEY));
			
			commonDao.getMap("WmsOutbound.CALL_PICKING_CANCEL_PROC_DL07", row);
		}
		
		return "OK";
	}
	
	@Transactional
	public String PickingCancelDL17(DataMap map) throws SQLException {
		List<DataMap> list = map.getList("list");
       
		SimpleDateFormat fmDate = new SimpleDateFormat("yyyyMMdd", Locale.KOREA);
		String date = fmDate.format(new Date());
		SimpleDateFormat fmTime = new SimpleDateFormat("HHmmss", Locale.KOREA);
		String time = fmTime.format(new Date());
       
		// Validation
		StringBuffer sb = new StringBuffer();
		for(DataMap item : list){
			if(sb.length() > 0)
				sb.append(" UNION ALL\n ");
			
			sb.append(" SELECT '").append(item.getMap("map").get("TASKKY")).append("' AS TASKKY, ");
			sb.append("        '").append(item.getMap("map").get("TASKIT")).append("' AS TASKIT FROM DUAL ");
		}
		
		map.setModuleCommand("WmsOutbound", "PICKING_CANCEL_ITEM"); // 쿼리키값 넣을것
		map.put("APPEND_QUERY", sb.toString());
		List<DataMap> validList = commonDao.getValidation(map);
		if(validList.size() > 0){
			DataMap valid = validList.get(0);
			return valid.getString("RESULTMSG");
		}
		
		DataMap row;
		for(int i=0;i<list.size();i++){
			row = list.get(i).getMap("map");
			
			row.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
			row.put(CommonConfig.SES_USER_OWNER_KEY, map.get(CommonConfig.SES_USER_OWNER_KEY));
			row.put(CommonConfig.SES_USER_WHAREHOUSE_KEY, map.get(CommonConfig.SES_USER_WHAREHOUSE_KEY));
			
			commonDao.getMap("WmsOutbound.CALL_PICKING_CANCEL_PROC", row);
		}
		
		return "OK";
	}
	
	@Transactional
	public Object savePrtseqDL04(DataMap map) throws SQLException {
		List<DataMap> list = map.getList("head");
		int count = 0;
		String opt;
		
		
		map.setModuleCommand("WmsOutbound", "SEQSTKNUM");
		Object stknum = commonDao.getObject(map);
		map.setModuleCommand("WmsOutbound", "SEQPRTSEQ");
		Object prtseq = commonDao.getObject(map);
		map.put("STKNUM", stknum);
		map.put("PRTSEQ", prtseq);
		DataMap row;
		for(int i=0;i<list.size();i++){
		    row = list.get(i).getMap("map");
			row.setModuleCommand("WmsOutbound", "DL04HEAD");	
			row.put("STKNUM", stknum);
			row.put("PRTSEQ", prtseq);
			row.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
			row.put(CommonConfig.SES_USER_OWNER_KEY, map.get(CommonConfig.SES_USER_OWNER_KEY));
			commonDao.update(row);
			
			count ++;
		}
		opt = map.getString("opt");
		if(opt.equals("INDUPK")){
			map.put("PRTTYP", 1);
		}else if(opt.equals ("INDUPA")){
			map.put("PRTTYP", 2);
		}else if(opt.equals ("INDUPB")){
			map.put("PRTTYP", 3);
		}
		
		map.setModuleCommand("WmsOutbound", "DL06PROC");
		commonDao.getMap(map);
		
		return prtseq;
	}
	
	@Transactional
	public int savePrtseqPT01(DataMap map) throws SQLException {
		List<DataMap> list = map.getList("head");
		int count = 0;
		
		DataMap row;
		for(int i=0;i<list.size();i++){
		    row = list.get(i).getMap("map");
			row.setModuleCommand("WmsOutbound", "PRTLGPT01");		
			row.put("PRTSEQ", map.get("PRTSEQ"));	
			
			row.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
			row.put(CommonConfig.SES_USER_OWNER_KEY, map.get(CommonConfig.SES_USER_OWNER_KEY));
			commonDao.insert(row);
			
			count ++;
		}
		
		return count;
	}
	
	@Transactional
	public int savePrtseqDL09(DataMap map) throws SQLException {
		List<DataMap> list = map.getList("head");
		int count = 0;
		
		DataMap row;
		for(int i=0;i<list.size();i++){
		    row = list.get(i).getMap("map");
			row.setModuleCommand("WmsOutbound", "PRTLGSHIP");		
			row.put("PRTSEQ", map.get("PRTSEQ"));	
			
			row.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
			row.put(CommonConfig.SES_USER_OWNER_KEY, map.get(CommonConfig.SES_USER_OWNER_KEY));
			commonDao.insert(row);
			
			count ++;
		}
		
		return count;
	}
	
	@Transactional
	public String closingDL04(DataMap map) throws SQLException {
		List<DataMap> headList = map.getList("head");
		
		// Validation
		StringBuffer sb = new StringBuffer();
		for(DataMap head : headList){
			if(sb.length() > 0)
				sb.append(" UNION ALL\n ");
			
			sb.append(" SELECT '").append(head.getMap("map").get("SHPOKY")).append("' AS SHPOKY FROM DUAL ");
		}
		
		map.setModuleCommand("WmsOutbound", "CLOSING_SHIPMENT"); // 쿼리키값 넣을것
		map.put("APPEND_QUERY", sb.toString());
		List<DataMap> validList = commonDao.getValidation(map);
		if(validList.size() > 0){
			DataMap valid = validList.get(0);
			return valid.getString("RESULTMSG");
		}
		
		int itemCount = 0;
		for(DataMap head : headList){
			head.put(CommonConfig.SES_USER_ID_KEY, map.get(CommonConfig.SES_USER_ID_KEY));
			head.put("SHPOKY", head.getMap("map").get("SHPOKY"));
			
			commonDao.update("WmsOutbound.ClosingShipment", head);
		}
		
		return "OK";
	}
}