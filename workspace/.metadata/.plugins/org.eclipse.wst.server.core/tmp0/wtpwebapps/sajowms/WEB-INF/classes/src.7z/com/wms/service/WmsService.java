package com.wms.service;

import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.common.dao.CommonDAO;
import com.common.bean.DataMap;

@Service
public class WmsService {

	@Autowired
	public CommonDAO commonDao;
	
	public String getDocSeq(String docType) throws SQLException{
		DataMap map = new DataMap("Common", "DOCUSEQ");
		map.put("DOCUTY", docType);
		
		return (String)commonDao.insert(map);
	}
	
	public String getNumSeq(String numObj) throws SQLException{
		DataMap map = new DataMap("Common", "NROBJ");
		map.put("NUMOBJ", numObj);
		
		return (String)commonDao.insert(map);
	}
}