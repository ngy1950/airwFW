import java.io.UnsupportedEncodingException;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "송성일";
		System.out.println(str.length());
		try {
			System.out.println(str.getBytes("EUC-KR").length);
			System.out.println(str.getBytes("UTF-8").length);
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}
}